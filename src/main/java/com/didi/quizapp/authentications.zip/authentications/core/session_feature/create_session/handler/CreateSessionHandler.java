package com.didi.quizapp.authentications.core.session_feature.create_session.handler;

import com.didi.quizapp.authentications.core.session_feature.create_session.dto.CreateSessionInputDTO;
import com.didi.quizapp.authentications.core.session_feature.create_session.dto.CreateSessionOutputDTO;
import com.didi.quizapp.authentications.core.session_feature.create_session.usecase.CreateSessionUseCase;
import com.didi.quizapp.authentications.core.session_feature.shared.dto.SessionOutputDTO;
import com.didi.quizapp.authentications.core.session_feature.shared.mapper.SessionCoreMapper;
import com.didi.quizapp.authentications.core.session_feature.shared.model.SessionModel;
import com.didi.quizapp.authentications.core.session_feature.shared.repository.SessionRepositoryPort;

import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@RequiredArgsConstructor
@Service
public class CreateSessionHandler implements CreateSessionUseCase {

    @Autowired
    private SessionRepositoryPort sessionRepositoryPort;
        
    @Override
    public CreateSessionOutputDTO createSession(UUID userId, CreateSessionInputDTO sessionInputDTO) {

        long startTime = System.currentTimeMillis();

        SessionModel sessionModel = sessionRepositoryPort.save(SessionCoreMapper.INSTANCE.map(sessionInputDTO));
        SessionOutputDTO sessionOutputDTO = SessionCoreMapper.INSTANCE.map(sessionModel);
        CreateSessionOutputDTO createSessionOutputDTO = new CreateSessionOutputDTO();
        sessionOutputDTO.setUserId(userId); // set the user file id
        createSessionOutputDTO.setData(sessionOutputDTO);

        long endTime = System.currentTimeMillis();

        createSessionOutputDTO.setElapsedTime(BigDecimal.valueOf(endTime - startTime));
        return createSessionOutputDTO;

    }
}
