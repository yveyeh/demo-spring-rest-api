package com.didi.quizapp.authentications.core.session_feature.shared.repository;

import com.didi.quizapp.authentications.core.session_feature.shared.model.SessionModel;
import com.didi.quizapp.authentications.core.shared.repository.BaseRepository;

public interface SessionRepositoryPort extends BaseRepository<SessionModel> {

}
