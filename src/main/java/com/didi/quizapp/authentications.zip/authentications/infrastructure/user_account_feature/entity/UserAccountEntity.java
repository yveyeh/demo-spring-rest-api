package com.didi.quizapp.authentications.infrastructure.user_account_feature.entity;

import java.util.UUID;

import com.didi.quizapp.authentications.enums.UserAccountStatus;
import com.didi.quizapp.authentications.infrastructure.shared.entity.BaseEntity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@SuperBuilder
@Table(name = "users")
public class UserAccountEntity extends BaseEntity {

    public static final UserAccountStatus DEFAUL_USER_ACCOUNT_STATUS = UserAccountStatus.PENDING;

    @Builder.Default
    @Column(name = "enabled")
    private boolean enabled = true;

    @Column(name = "sponsorship_code")
    private String sponsorshipCode;

    @Column(name = "sponsor")
    private UUID sponsor;

    @Builder.Default
    @Enumerated(EnumType.STRING)
    @Column(name = "user_acc_status")
    private UserAccountStatus userAccountStatus = DEFAUL_USER_ACCOUNT_STATUS;

    @Column(name = "company_id")
    private UUID companyId;

}

