package com.didi.quizapp.authentications.core.session_feature.create_session.usecase;

import com.didi.quizapp.authentications.core.session_feature.create_session.dto.CreateSessionInputDTO;
import com.didi.quizapp.authentications.core.session_feature.create_session.dto.CreateSessionOutputDTO;
import java.util.UUID;

public interface CreateSessionUseCase {

    CreateSessionOutputDTO createSession(UUID userId, CreateSessionInputDTO sessionInputDTO);

}
