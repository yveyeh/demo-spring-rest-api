package com.didi.quizapp.authentications.enums;

public enum UserAccountStatus {
    SUSPENDED,
    BLOCKED,
    BANISHED,
    ACTIVE,
    PENDING
}
