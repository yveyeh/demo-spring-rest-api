package com.didi.quizapp.authentications.types;

import jakarta.persistence.Embeddable;
import lombok.RequiredArgsConstructor;

@Embeddable
@RequiredArgsConstructor
public class IPAddress {

    private String ip;
    private String isp;
    private String dns;
    private String zip;

    public IPAddress(String ip, String isp, String dns, String zip) {
        this.ip = validateIPAddress(ip);
        this.isp = isp;
        this.dns = dns;
        this.zip = zip;
    }

    /**
     * @return String return the ip
     */
    public String getIP() {
        return ip;
    }

    /**
     * @return String return the isp
     */
    public String getISP() {
        return isp;
    }

    /**
     * @return String return the dns
     */
    public String getDNS() {
        return dns;
    }

    /**
     * @return String return the zip
     */
    public String getZIP() {
        return zip;
    }

    private String validateIPAddress(String ip) throws IllegalArgumentException {
        if (!isValidIPAddress(ip)) {
            throw new IllegalArgumentException("Invalid IP address: " + ip);
        }
        return ip;
    }

    private static boolean isValidIPAddress(String ip) {
        // Regex for both IPv4 and IPv6 addresses
        final String REGEX = "^(?:(?:[0-9]{1,3}\\.){3}[0-9]{1,3})|(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){6}(?:[0-9a-fA-F]{1,4}|:[0-9a-fA-F]{1,4})|...)";
        return (ip == null ? "" : ip).matches(REGEX);
    }
      
}
