package com.didi.quizapp.authentications.infrastructure.session_feature.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.didi.quizapp.authentications.core.session_feature.shared.model.SessionModel;
import com.didi.quizapp.authentications.core.session_feature.shared.repository.SessionRepositoryPort;
import com.didi.quizapp.authentications.infrastructure.session_feature.entity.SessionEntity;
import com.didi.quizapp.authentications.infrastructure.session_feature.mapper.SessionInfraMapper;

import jakarta.validation.constraints.NotNull;

@Repository
public class SessionRepositoryAdapter implements SessionRepositoryPort {

    @Autowired
    private SessionRepository sessionRepository;

    @Override
    public SessionModel saveAndFlush(SessionModel entity) {
        return SessionInfraMapper.INSTANCE.map(
                sessionRepository.saveAndFlush(
                        SessionInfraMapper.INSTANCE.map(entity)));
    }

    @Override
    public SessionModel getById(UUID uuid) {
        return SessionInfraMapper.INSTANCE.map(sessionRepository.getReferenceById(uuid));
    }

    @Override
    public SessionModel save(SessionModel entity) {
        SessionEntity innerMapper = SessionInfraMapper.INSTANCE.map(entity);
        SessionEntity action = sessionRepository.save(innerMapper);
        SessionModel outerMapper = SessionInfraMapper.INSTANCE.map(action);
        return outerMapper;
    }

    @Override
    public Optional<SessionModel> findById(@NotNull UUID uuid) {
        return Optional.of(SessionInfraMapper.INSTANCE.map(
                sessionRepository.findById(
                        uuid).get()));
    }

    @Override
    public boolean existsById(UUID uuid) {
        return sessionRepository.existsById(uuid);
    }

    @Override
    public List<SessionModel> findAll() {
        return SessionInfraMapper.INSTANCE.map(sessionRepository.findAll());
    }

    @Override
    public long count() {
        return sessionRepository.count();
    }

    @Override
    public void delete(SessionModel model) {
        sessionRepository.delete(SessionInfraMapper.INSTANCE.map(model));
    }

    @Override
    public void deleteById(UUID uuid) {
        sessionRepository.deleteById(uuid);
    }

    @Override
    public Page<SessionModel> findAll(Pageable pageable) {
        Page<SessionEntity> sessionEntityPage = sessionRepository.findAll(pageable);

        List<SessionModel> sessionModels = SessionInfraMapper.INSTANCE.map(sessionEntityPage.getContent());

        return new PageImpl<>(sessionModels, pageable, count());
    }

    @Override
    public Page<SessionModel> findByUserId(Pageable pageable, UUID userId) {
        Page<SessionEntity> sessionEntityPage = sessionRepository.findByUserId(pageable, userId);

        List<SessionModel> sessionModels = SessionInfraMapper.INSTANCE.map(sessionEntityPage.getContent());

        return new PageImpl<>(sessionModels, pageable, count());
    }
}
