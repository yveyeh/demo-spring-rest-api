package com.didi.quizapp.authentications.core.session_feature.shared.mapper;

import com.didi.quizapp.authentications.core.session_feature.create_session.dto.CreateSessionInputDTO;
import com.didi.quizapp.authentications.core.session_feature.shared.dto.SessionOutputDTO;
import com.didi.quizapp.authentications.core.session_feature.shared.model.SessionModel;
// import com.didi.quizapp.authentications.core.session_feature.update_session.dto.UpdateSessionInputDTO;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
// import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SessionCoreMapper {
    SessionCoreMapper INSTANCE = Mappers.getMapper(SessionCoreMapper.class);

    SessionOutputDTO map(SessionModel sessionModel);

    List<SessionOutputDTO> map(List<SessionModel> sessionModelList);

    SessionModel map(CreateSessionInputDTO sessionInputDTO);

    // void updateSessionModelFromUpdateSessionInputDTO(UpdateSessionInputDTO sessionInputDTO, @MappingTarget SessionModel sessionModel);
}