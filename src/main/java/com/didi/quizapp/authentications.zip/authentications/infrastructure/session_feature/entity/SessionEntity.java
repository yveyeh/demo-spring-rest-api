package com.didi.quizapp.authentications.infrastructure.session_feature.entity;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.format.annotation.DateTimeFormat;

import com.didi.quizapp.authentications.types.Browser;
import com.didi.quizapp.authentications.types.Device;
import com.didi.quizapp.authentications.types.IPAddress;
import com.didi.quizapp.authentications.types.OperatingSystem;
import com.didi.quizapp.authentications.infrastructure.shared.entity.BaseEntity;

import jakarta.persistence.*;
import jakarta.persistence.Entity;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@SuperBuilder
@Table(name = "sessions")
public class SessionEntity extends BaseEntity {

    @Column(name = "token")
    private String token;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    @Column(name = "last_seen")
    private OffsetDateTime lastSeen;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    @Column(name = "expires")
    private OffsetDateTime expires;

    @Builder.Default
    @Column(name = "is_valid")
    private boolean isValid = true;

    @Column(name = "user_id")
    private UUID userId;

    @Embedded
    private IPAddress ipAddress;

    @Embedded
    private Browser browser;

    @Embedded 
    private Device device;

    @Embedded
    private OperatingSystem operatingSystem;

}
