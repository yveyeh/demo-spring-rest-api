package com.didi.quizapp.authentications.infrastructure.session_feature.repository;

import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.didi.quizapp.authentications.infrastructure.session_feature.entity.SessionEntity;

public interface SessionRepository extends JpaRepository<SessionEntity, UUID> {

    Page<SessionEntity> findByUserId(Pageable pageable, UUID userId);

}
