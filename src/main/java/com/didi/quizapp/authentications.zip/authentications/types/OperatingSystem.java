package com.didi.quizapp.authentications.types;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.RequiredArgsConstructor;

@Embeddable
@RequiredArgsConstructor
public class OperatingSystem {

    private String maker;

    @Column(name = "os_name") // Specify a unique column name
    private String name;


    /**
     * @return String return the maker
     */
    public String getMaker() {
        return maker;
    }

    /**
     * @return String return the name
     */
    public String getName() {
        return name;
    }

}
