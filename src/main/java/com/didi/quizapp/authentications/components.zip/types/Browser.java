package com.didi.quizapp.authentications.types;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.RequiredArgsConstructor;

@Embeddable
@RequiredArgsConstructor
public class Browser {

    @Column(name = "browser_name") // Specify a unique column name
    private String name;
    
    private String version;
    private String arch;
    private String acceptLanguage;
    private String userAgent;


    /**
     * @return String return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return String return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * @return String return the arch
     */
    public String getArch() {
        return arch;
    }

    /**
     * @return String return the acceptLanguage
     */
    public String getAcceptLanguage() {
        return acceptLanguage;
    }

    /**
     * @return String return the userAgent
     */
    public String getUserAgent() {
        return userAgent;
    }

}
