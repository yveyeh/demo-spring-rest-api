package com.didi.quizapp.authentications.enums;

public enum AuthProvider {
    GOOGLE,
    FACEBOOK,
    GITHUB,
    LINKEDIN,
    YAHOO,
    TWITTER,
    MICROSOFT
}
