package com.didi.quizapp.authentications.app.session_feature.shared.mapper;

// import com.didi.quizapp.authentications.app.session_feature.consult_session_details.dto.ConsultSessionDetailsResponseDTO;
// import com.didi.quizapp.authentications.app.session_feature.consult_session_list.dto.ConsultSessionListResponseDTO;
import com.didi.quizapp.authentications.app.session_feature.create_session.dto.CreateSessionRequestDTO;
import com.didi.quizapp.authentications.app.session_feature.create_session.dto.CreateSessionResponseDTO;
// import com.didi.quizapp.authentications.app.session_feature.update_session.dto.UpdateSessionRequestDTO;
// import com.didi.quizapp.authentications.app.session_feature.update_session.dto.UpdateSessionResponseDTO;
// import com.didi.quizapp.authentications.core.session_feature.consult_session_details.dto.ConsultSessionDetailsOutputDTO;
// import com.didi.quizapp.authentications.core.session_feature.consult_session_list.dto.ConsultSessionListOutputDTO;
import com.didi.quizapp.authentications.core.session_feature.create_session.dto.CreateSessionInputDTO;
import com.didi.quizapp.authentications.core.session_feature.create_session.dto.CreateSessionOutputDTO;
// import com.didi.quizapp.authentications.core.session_feature.update_session.dto.UpdateSessionInputDTO;
// import com.didi.quizapp.authentications.core.session_feature.update_session.dto.UpdateSessionOutputDTO;

import org.mapstruct.Mapper;
// import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SessionAppMapper {

    SessionAppMapper INSTANCE = Mappers.getMapper(SessionAppMapper.class);

    // ConsultSessionDetailsResponseDTO map(ConsultSessionDetailsOutputDTO consultSessionDetailsOutputDTO);

    // ConsultSessionListResponseDTO map(ConsultSessionListOutputDTO consultSessionListOutputDTO);

    CreateSessionInputDTO map(CreateSessionRequestDTO CreateSessionRequestDTO);

    CreateSessionResponseDTO map(CreateSessionOutputDTO createSessionOutputDTO);

    // UpdateSessionResponseDTO map(UpdateSessionOutputDTO updateSessionOutputDTO);

    // UpdateSessionInputDTO map(UpdateSessionRequestDTO updateSessionRequestDTO);
    
}
