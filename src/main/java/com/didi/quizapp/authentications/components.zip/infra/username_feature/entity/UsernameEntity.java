package com.didi.quizapp.authentications.infra.username_feature.entity;

import com.didi.quizapp.authentications.enums.AuthProvider;
import com.didi.quizapp.authentications.enums.UsernameType;
import com.didi.quizapp.authentications.infra.shared.entity.BaseEntity;

import jakarta.persistence.*;
import java.util.List;
import java.util.UUID;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@SuperBuilder
@Table(name = "usernames")
public class UsernameEntity extends BaseEntity {

    @Column(name = "value")
    private String value;

    @Enumerated(EnumType.STRING)
    @Column(name = "type")
    private UsernameType type;

    @Builder.Default
    @Column(name = "verified")
    private boolean verified = false;

    @Column(name = "auth_providers")
    private List<AuthProvider> authProviders;

    @Builder.Default
    @Column(name = "actived")
    private boolean actived = true;

    @Column(name = "credential_id")
    private UUID credentialId;

}
