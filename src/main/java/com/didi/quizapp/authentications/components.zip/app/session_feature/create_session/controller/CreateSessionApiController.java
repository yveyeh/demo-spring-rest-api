package com.didi.quizapp.authentications.app.session_feature.create_session.controller;

import com.didi.quizapp.authentications.app.session_feature.create_session.api.CreateSessionApi;
import com.didi.quizapp.authentications.app.session_feature.create_session.dto.CreateSessionRequestDTO;
import com.didi.quizapp.authentications.app.session_feature.create_session.dto.CreateSessionResponseDTO;
import com.didi.quizapp.authentications.app.session_feature.shared.mapper.SessionAppMapper;
import com.didi.quizapp.authentications.core.session_feature.create_session.dto.CreateSessionInputDTO;
import com.didi.quizapp.authentications.core.session_feature.create_session.dto.CreateSessionOutputDTO;
import com.didi.quizapp.authentications.core.session_feature.create_session.handler.CreateSessionHandler;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import lombok.RequiredArgsConstructor;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class CreateSessionApiController implements CreateSessionApi {

    @Autowired
    private CreateSessionHandler createSessionHandler;

    @PostMapping("iam/authentications/users/{userId}/sessions")
    @Override
    public ResponseEntity<CreateSessionResponseDTO> _createSession(@PathVariable("userId") UUID userId, @RequestBody CreateSessionRequestDTO createSessionRequestDTO) {
        createSessionRequestDTO.setUserId(userId);
        System.out.println(createSessionRequestDTO);
        try {
            CreateSessionInputDTO requestDTO = SessionAppMapper.INSTANCE.map(createSessionRequestDTO);
            CreateSessionOutputDTO outputDTO = createSessionHandler.createSession(userId, requestDTO);
            CreateSessionResponseDTO responseDTO = SessionAppMapper.INSTANCE.map(outputDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } catch (IllegalArgumentException exception) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
