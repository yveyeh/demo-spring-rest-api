package com.didi.quizapp.authentications.types;

import jakarta.persistence.Embeddable;
import lombok.RequiredArgsConstructor;

@Embeddable
@RequiredArgsConstructor
public class Device {

    private String constructor;
    private String model;


    /**
     * @return String return the constructor
     */
    public String getConstructor() {
        return constructor;
    }

    /**
     * @return String return the model
     */
    public String getModel() {
        return model;
    }

}
