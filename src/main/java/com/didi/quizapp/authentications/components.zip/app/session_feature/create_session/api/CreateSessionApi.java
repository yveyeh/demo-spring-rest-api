package com.didi.quizapp.authentications.app.session_feature.create_session.api;

import com.didi.quizapp.authentications.app.session_feature.create_session.dto.CreateSessionRequestDTO;
import com.didi.quizapp.authentications.app.session_feature.create_session.dto.CreateSessionResponseDTO;
import com.didi.quizapp.authentications.shared.ResponseErrorDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@Validated
@Tag(name = "CreateSession", description = "Endpoint feature to create a session")
public interface CreateSessionApi {

    /**
     * POST iam/authentications/users/{user_id}/sessions : Create a session
     * As system runner, I can create a session
     *
     * @param createSessionRequestDTO Session payload for creation operation (required)
     * @return This response is return when operation succeeded (status code 201)
     *         or Returned when an error occur (status code 200)
     */
    @Operation(
        operationId = "createSession",
        summary = "Create a session",
        description = "As system runner, I can create a session",
        tags = { "CreateSession" },
        responses = {
            @ApiResponse(responseCode = "201", description = "This response is return when operation succeeded", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = CreateSessionResponseDTO.class))
            }),
            @ApiResponse(responseCode = "default", description = "Returned when an error occurs", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseErrorDTO.class))
            })
        }
    )
    @RequestMapping(
        method = RequestMethod.POST,
        value = "iam/authentications/users/{userId}/sessions",
        produces = { "application/json" },
        consumes = { "application/json" }
    )
    
    ResponseEntity<CreateSessionResponseDTO> _createSession(
        @Parameter(name = "userId", description = "Unique identifier (UUID) of the user for which to create a session", required = true, in = ParameterIn.PATH) 
        @PathVariable("userId") UUID userId,
        @Valid 
        @RequestBody 
        @Parameter(name = "createSessionRequestDTO", description = "Session payload for creation operation", required = true) 
        CreateSessionRequestDTO createSessionRequestDTO
    );

}
