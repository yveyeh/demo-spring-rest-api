package com.didi.quizapp.authentications.infra.session_feature.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.didi.quizapp.authentications.core.session_feature.shared.model.SessionModel;
import com.didi.quizapp.authentications.infra.session_feature.entity.SessionEntity;

@Mapper
public interface SessionInfraMapper {

    SessionInfraMapper INSTANCE = Mappers.getMapper(SessionInfraMapper.class);

    SessionModel map(SessionEntity sessionEntity);

    SessionEntity map(SessionModel sessionModel);

    List<SessionModel> map(List<SessionEntity> sessionEntities);

}
