package com.didi.quizapp.authentications.enums;

public enum UsernameType {
    EMAIL,
    PHONE,
    NAME
}
