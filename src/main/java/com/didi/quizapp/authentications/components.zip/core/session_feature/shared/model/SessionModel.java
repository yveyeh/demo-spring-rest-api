package com.didi.quizapp.authentications.core.session_feature.shared.model;

import com.didi.quizapp.authentications.types.Browser;
import com.didi.quizapp.authentications.types.Device;
import com.didi.quizapp.authentications.types.IPAddress;
import com.didi.quizapp.authentications.types.OperatingSystem;
import com.didi.quizapp.authentications.core.shared.model.BaseModel;

import jakarta.persistence.Embedded;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.format.annotation.DateTimeFormat;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
public class SessionModel extends BaseModel {

    private String token;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime lastSeen;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime expires;

    @Builder.Default
    private boolean isValid = true;

    private UUID userId;

    @Embedded
    private IPAddress ipAddress;

    @Embedded
    private Browser browser;

    @Embedded 
    private Device device;

    @Embedded
    private OperatingSystem operatingSystem;

}
