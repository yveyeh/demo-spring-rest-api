package com.didi.quizapp.authentications.app.session_feature.create_session.dto;

import java.time.OffsetDateTime;
import java.util.UUID;

import com.didi.quizapp.authentications.types.Browser;
import com.didi.quizapp.authentications.types.Device;
import com.didi.quizapp.authentications.types.IPAddress;
import com.didi.quizapp.authentications.types.OperatingSystem;
import com.didi.quizapp.helpers.Equals;
import com.didi.quizapp.helpers.HashCode;
import com.didi.quizapp.helpers.ToString;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Embedded;
import jakarta.validation.Valid;

public class CreateSessionRequestDTO {

    private String token;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime lastSeen;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime expires;

    private boolean isValid = true;

    private UUID userId;

    @Embedded
    private IPAddress ipAddress;

    @Embedded
    private Browser browser;

    @Embedded 
    private Device device;

    @Embedded
    private OperatingSystem operatingSystem;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime createdAt;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime updatedAt;


    /**
     * Set the token field.
     *
     * @param token The token to set
     * @return The modified CreateSessionRequestDTO instance
     */
    public CreateSessionRequestDTO token(String token) {
        this.token = token;
        return this;
    }

    /**
     * @return string return the token
     */
    @Valid
    @Schema(name = "token", description = "The access token in the session", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("token")
    public String getToken() {
        return token;
    }

    /**
     * @param token the token to set
     */
    @JsonProperty("token")
    public void setToken(String token) {
        this.token = token;
    }

    public CreateSessionRequestDTO createdAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    /**
     * The creation date of the session
     * 
     * @return createdAt
     */
    @Valid
    @Schema(name = "created_at", description = "The creation date of the session", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("created_at")
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public CreateSessionRequestDTO updatedAt(OffsetDateTime updatedAt) {
        this.updatedAt = updatedAt;
        return this;
    }

    /**
     * The last modified date of the session
     * 
     * @return updatedAt
     */
    @Valid
    @Schema(name = "updated_at", description = "The last modified date of the session", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("updated_at")
    public OffsetDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(OffsetDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * Set the lastSeen field.
     *
     * @param lastSeen The lastSeen to set
     * @return The modified CreateSessionRequestDTO instance
     */
    public CreateSessionRequestDTO lastSeen(OffsetDateTime lastSeen) {
        this.lastSeen = lastSeen;
        return this;
    }

    /**
     * @return OffsetDateTime return the lastSeen
     */
    @Valid
    @Schema(name = "last_seen", description = "The last time a user created a session", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("last_seen")
    public OffsetDateTime getLastSeen() {
        return lastSeen;
    }

    /**
     * @param lastSeen the lastSeen to set
     */
    @JsonProperty("last_seen")
    public void setLastSeen(OffsetDateTime lastSeen) {
        this.lastSeen = lastSeen;
    }

    /**
     * Set the expires field.
     *
     * @param expires The expires value to set
     * @return The modified CreateSessionRequestDTO instance
     */
    public CreateSessionRequestDTO expires(OffsetDateTime expires) {
        this.expires = expires;
        return this;
    }

    /**
     * @return OffsetDateTime return the expires
     */
    @Valid
    @Schema(name = "expires", description = "The time at which the session expires", requiredMode = Schema.RequiredMode.REQUIRED)
    @JsonProperty("expires")
    public OffsetDateTime getExpires() {
        return expires;
    }

    /**
     * @param expires the expires to set
     */
    @JsonProperty("expires")
    public void setExpires(OffsetDateTime expires) {
        this.expires = expires;
    }

    /**
     * Set the isValid field.
     *
     * @param isValid The isValid state to set
     * @return The modified CreateSessionRequestDTO instance
     */
    public CreateSessionRequestDTO isValid(boolean isValid) {
        this.isValid = isValid;
        return this;
    }

    /**
     * @return boolean return the isValid
     */
    @Valid
    @Schema(name = "is_valid", description = "If the session is valid or invalid", requiredMode = Schema.RequiredMode.REQUIRED)
    @JsonProperty("is_valid")
    public boolean isIsValid() {
        return isValid;
    }

    /**
     * @param isValid the isValid to set
     */
    @JsonProperty("is_valid")
    public void setIsValid(boolean isValid) {
        this.isValid = isValid;
    }

    /**
     * Set the userId field.
     *
     * @param userId The userId to set
     * @return The modified CreateSessionRequestDTO instance
     */
    public CreateSessionRequestDTO userId(UUID userId) {
        this.userId = userId;
        return this;
    }

    /**
     * @return UUID return the userId
     */
    @Valid
    @Schema(name = "user_id", description = "The ID of the user that created the session", requiredMode = Schema.RequiredMode.REQUIRED)
    @JsonProperty("user_id")
    public UUID getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    @JsonProperty("user_id")
    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    /**
     * Set the ipAddress field.
     *
     * @param ipAddress The ipAddress to set
     * @return The modified CreateSessionRequestDTO instance
     */
    public CreateSessionRequestDTO ipAddress(IPAddress ipAddress) {
        this.ipAddress = ipAddress;
        return this;
    }

    /**
     * @return IPAddress return the ipAddress
     */
    @Valid
    @Schema(name = "ip_address", description = "The IP address of the session", requiredMode = Schema.RequiredMode.REQUIRED)
    @JsonProperty("ip_address")
    public IPAddress getIpAddress() {
        return ipAddress;
    }

    /**
     * @param ipAddress the ipAddress to set
     */
    @JsonProperty("ip_address")
    public void setIpAddress(IPAddress ipAddress) {
        this.ipAddress = ipAddress;
    }

    /**
     * @return Browser return the browser
     */
    @Valid
    @Schema(name = "browser", description = "The client browser through which the user created a session", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("browser")
    public Browser getBrowser() {
        return browser;
    }

    /**
     * @param browser the browser to set
     */
    @JsonProperty("browser")
    public void setBrowser(Browser browser) {
        this.browser = browser;
    }

    /**
     * @return Device return the device
     */
    @Valid
    @Schema(name = "device", description = "The client device through which the user created a session", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("device")
    public Device getDevice() {
        return device;
    }

    /**
     * @param device the device to set
     */
    @JsonProperty("device")
    public void setDevice(Device device) {
        this.device = device;
    }

    /**
     * @return OperatingSystem return the operatingSystem
     */
    @Valid
    @Schema(name = "operating_system", description = "The client operating system through which the user created a session", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("operating_system")
    public OperatingSystem getOperatingSystem() {
        return operatingSystem;
    }

    /**
     * @param operatingSystem the operatingSystem to set
     */
    @JsonProperty("operating_system")
    public void setOperatingSystem(OperatingSystem operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    @Override
    public boolean equals(Object object) {
        return Equals.equals(this, object);
    }

    @Override
    public int hashCode() {
        return HashCode.hashCode(this);
    }

    @Override
    public String toString() {
        return ToString.toString(this);
    }

}
