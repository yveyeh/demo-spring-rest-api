package com.didi.quizapp.identities.validations.app.docfile_verification_feature.delete_docfile_verification.api;

import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.didi.quizapp.identities.validations.shared.ResponseErrorDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@Validated
@Tag(name = "DeleteDocFileVerification", description = "Endpoint feature to delete a doc file verification")
public interface DeleteDocFileVerificationApi {

    /**
     * DELETE /iam/identities/validations/docfile/verifications/{id} : Delete DocFileVerification Details
     * Delete the details of a DocFileVerification identified by its ID.
     *
     * @param id Unique identifier (UUID) of the file to delete (required)
     * @return This response is returned when operation succeeded (status code 204)
     *         or Returned when an error occur (status code 404)
     */
    @Operation(
        operationId = "deleteDocFileVerificationDetails",
        summary = "Delete DocFileVerification Details",
        description = "Delete the details of a DocFileVerification identified by it ID.",
        tags = { "DeleteDocFileVerification" },
        responses = {
            @ApiResponse(responseCode = "204", description = "This response is returned when operation succeeded"),
            @ApiResponse(responseCode = "default", description = "Returned when an error occurs", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseErrorDTO.class))
            })
        }
    )
    @RequestMapping(
        method = RequestMethod.DELETE,
        value = "/iam/identities/validations/docfile/verifications/{id}",
        produces = { "application/json" }
    )
    
    ResponseEntity<String> _deleteDocFileVerificationDetails(
        @Parameter(name = "id", description = "Unique identifier (UUID) of the doc file verification to delete", required = true, in = ParameterIn.PATH) @PathVariable("id") UUID id
    );

}
