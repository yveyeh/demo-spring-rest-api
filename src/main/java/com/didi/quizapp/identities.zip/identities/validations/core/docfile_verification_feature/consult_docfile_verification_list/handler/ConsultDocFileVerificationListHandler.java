package com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_list.handler;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_list.dto.ConsultDocFileVerificationListOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_list.usecase.ConsultDocFileVerificationListUseCase;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.dto.DocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.mapper.DocFileVerificationCoreMapper;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model.DocFileVerificationModel;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.repository.DocFileVerificationRepositoryPort;
import com.didi.quizapp.identities.validations.core.shared.dto.MetaDataDTO;
import com.didi.quizapp.identities.validations.core.shared.utils.Utils;

@Service
public class ConsultDocFileVerificationListHandler implements ConsultDocFileVerificationListUseCase {

    @Autowired
    private DocFileVerificationRepositoryPort docFileVerificationRepositoryPort;

    // public ConsultDocFileVerificationListHandler(DocFileVerificationRepositoryPort docFileVerificationRepositoryPort) {
    //     this.docFileVerificationRepositoryPort = docFileVerificationRepositoryPort;
    // }

    @Override
    public ConsultDocFileVerificationListOutputDTO consultDocFileVerificationList(UUID docFileId, Integer page, Integer size) {
        long startTime = System.currentTimeMillis();

        Pageable pageable = PageRequest.of(page - 1, size);

        Page<DocFileVerificationModel> docFileVerificationModelPage = docFileVerificationRepositoryPort.findByDocFileId(pageable, docFileId);

        MetaDataDTO metaDataDTO = Utils.setMetaDataFromEntityPage(docFileVerificationModelPage);

        ConsultDocFileVerificationListOutputDTO consultDocFileVerificationListOutputDTO = new ConsultDocFileVerificationListOutputDTO();

        consultDocFileVerificationListOutputDTO.setMetaData(metaDataDTO);

        List<DocFileVerificationOutputDTO> docFileVerificationOutputDTOs = DocFileVerificationCoreMapper.INSTANCE
                .map(docFileVerificationModelPage.getContent());

        consultDocFileVerificationListOutputDTO.setData(docFileVerificationOutputDTOs);

        long endTime = System.currentTimeMillis();

        consultDocFileVerificationListOutputDTO.setElapsedTime(BigDecimal.valueOf(endTime - startTime));

        return consultDocFileVerificationListOutputDTO;
    }

}
