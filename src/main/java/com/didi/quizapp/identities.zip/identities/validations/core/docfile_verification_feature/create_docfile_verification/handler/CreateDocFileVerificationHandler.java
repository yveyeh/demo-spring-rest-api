package com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.handler;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.usecase.CreateDocFileVerificationUseCase;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.dto.DocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.mapper.DocFileVerificationCoreMapper;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model.DocFileVerificationModel;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.repository.DocFileVerificationRepositoryPort;

import org.springframework.beans.factory.annotation.Autowired;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.UUID;

@RequiredArgsConstructor
@Service
public class CreateDocFileVerificationHandler implements CreateDocFileVerificationUseCase {

    @Autowired
    private DocFileVerificationRepositoryPort docFileVerificationRepositoryPort;

    // public CreateDocFileVerificationHandler(DocFileVerificationRepositoryPort docFileVerificationRepositoryPort) {
    //     this.docFileVerificationRepositoryPort = docFileVerificationRepositoryPort;
    // }

    @Override
    public CreateDocFileVerificationOutputDTO createDocFileVerification(UUID docFileId,
            CreateDocFileVerificationInputDTO docFileVerificationInputDTO) {

        long startTime = System.currentTimeMillis();

        DocFileVerificationModel docFileVerificationModel = docFileVerificationRepositoryPort
                .save(DocFileVerificationCoreMapper.INSTANCE.map(docFileVerificationInputDTO));
        DocFileVerificationOutputDTO docFileVerificationOutputDTO = DocFileVerificationCoreMapper.INSTANCE
                .map(docFileVerificationModel);
        CreateDocFileVerificationOutputDTO createDocFileVerificationOutputDTO = new CreateDocFileVerificationOutputDTO();
        docFileVerificationOutputDTO.setDocFileId(docFileId); // set the doc file id
        createDocFileVerificationOutputDTO.setData(docFileVerificationOutputDTO);

        long endTime = System.currentTimeMillis();

        createDocFileVerificationOutputDTO.setElapsedTime(BigDecimal.valueOf(endTime - startTime));
        return createDocFileVerificationOutputDTO;

    }
}
