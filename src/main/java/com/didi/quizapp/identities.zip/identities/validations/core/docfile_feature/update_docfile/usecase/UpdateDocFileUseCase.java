package com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.usecase;
import java.util.UUID;

import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.dto.UpdateDocFileInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.dto.UpdateDocFileOutputDTO;

public interface UpdateDocFileUseCase {
    UpdateDocFileOutputDTO update(UUID docFileId, UpdateDocFileInputDTO docFileInputDTO);
}
