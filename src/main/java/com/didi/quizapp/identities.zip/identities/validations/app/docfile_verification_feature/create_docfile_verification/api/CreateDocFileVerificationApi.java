package com.didi.quizapp.identities.validations.app.docfile_verification_feature.create_docfile_verification.api;

import com.didi.quizapp.identities.validations.app.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationResponseDTO;
import com.didi.quizapp.identities.validations.shared.ResponseErrorDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@Validated
@Tag(name = "CreateDocFileVerification", description = "Endpoint feature to create a doc file verification")
public interface CreateDocFileVerificationApi {

    /**
     * POST /iam/identities/validations/docfiles/{docFileId}/verifications : Create a doc file verification
     * As system runner, I can create a doc file verification
     *
     * @param createDocFileVerificationRequestDTO DocFileVerification payload for creation operation (required)
     * @return This response is return when operation succeeded (status code 201)
     *         or Returned when an error occur (status code 200)
     */
    @Operation(
        operationId = "createDocFileVerification",
        summary = "Create a doc file verification",
        description = "As system runner, I can create a doc file verification",
        tags = { "CreateDocFileVerification" },
        responses = {
            @ApiResponse(responseCode = "201", description = "This response is return when operation succeeded", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = CreateDocFileVerificationResponseDTO.class))
            }),
            @ApiResponse(responseCode = "default", description = "Returned when an error occurs", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseErrorDTO.class))
            })
        }
    )
    @RequestMapping(
        method = RequestMethod.POST,
        value = "/iam/identities/validations/docfiles/{docFileId}/verifications",
        produces = { "application/json" },
        consumes = { "application/json" }
    )
    
    ResponseEntity<CreateDocFileVerificationResponseDTO> _createDocFileVerification(
        @Parameter(name = "docFileId", description = "Unique identifier (UUID) of the docfile for which to create a verification", required = true, in = ParameterIn.PATH) 
        @PathVariable("docFileId") UUID docFileId,
        @Valid 
        @RequestBody 
        @Parameter(name = "CreateDocFileVerificationRequestDTO", description = "DocFileVerification payload for creation operation", required = true) 
        CreateDocFileVerificationRequestDTO createDocFileVerificationRequestDTO
    );

}
