package com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.mapper;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.dto.DocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model.DocFileVerificationModel;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationInputDTO;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface DocFileVerificationCoreMapper {
    DocFileVerificationCoreMapper INSTANCE = Mappers.getMapper(DocFileVerificationCoreMapper.class);

    DocFileVerificationOutputDTO map(DocFileVerificationModel docFileVerificationModel);

    List<DocFileVerificationOutputDTO> map(List<DocFileVerificationModel> docFileVerificationModelList);

    DocFileVerificationModel map(CreateDocFileVerificationInputDTO docFileVerificationInputDTO);

    void updateDocFileVerificationModelFromUpdateDocFileVerificationInputDTO(
            UpdateDocFileVerificationInputDTO docFileVerificationInputDTO,
            @MappingTarget DocFileVerificationModel docFileVerificationModel);
}