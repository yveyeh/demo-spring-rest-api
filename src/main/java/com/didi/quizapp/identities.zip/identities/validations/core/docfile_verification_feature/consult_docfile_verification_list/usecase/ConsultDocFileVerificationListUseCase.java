package com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_list.usecase;

import java.util.UUID;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_list.dto.ConsultDocFileVerificationListOutputDTO;

public interface ConsultDocFileVerificationListUseCase {
    ConsultDocFileVerificationListOutputDTO consultDocFileVerificationList(UUID docFileId, Integer page, Integer size);
}
