package com.didi.quizapp.identities.validations.app.docfile_verification_feature.shared.mapper;

import com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_details.dto.ConsultDocFileVerificationDetailsResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_list.dto.ConsultDocFileVerificationListResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationResponseDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_details.dto.ConsultDocFileVerificationDetailsOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_list.dto.ConsultDocFileVerificationListOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationOutputDTO;

import org.mapstruct.Mapper;
// import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface DocFileVerificationAppMapper {

        DocFileVerificationAppMapper INSTANCE = Mappers.getMapper(DocFileVerificationAppMapper.class);

        ConsultDocFileVerificationDetailsResponseDTO map(
                        ConsultDocFileVerificationDetailsOutputDTO consultDocFileVerificationDetailsOutputDTO);

        ConsultDocFileVerificationListResponseDTO map(
                        ConsultDocFileVerificationListOutputDTO consultDocFileVerificationListOutputDTO);

        CreateDocFileVerificationInputDTO map(CreateDocFileVerificationRequestDTO CreateDocFileVerificationRequestDTO);

        CreateDocFileVerificationResponseDTO map(CreateDocFileVerificationOutputDTO createDocFileVerificationOutputDTO);

        UpdateDocFileVerificationResponseDTO map(UpdateDocFileVerificationOutputDTO updateDocFileVerificationOutputDTO);

        UpdateDocFileVerificationInputDTO map(UpdateDocFileVerificationRequestDTO updateDocFileVerificationRequestDTO);

}
