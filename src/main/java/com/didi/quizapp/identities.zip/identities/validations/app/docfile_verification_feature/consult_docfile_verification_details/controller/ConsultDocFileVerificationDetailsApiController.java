package com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_details.controller;

import com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_details.api.ConsultDocFileVerificationDetailsApi;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_details.dto.ConsultDocFileVerificationDetailsResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.shared.mapper.DocFileVerificationAppMapper;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_details.dto.ConsultDocFileVerificationDetailsOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_details.handler.ConsultDocFileVerificationDetailsHandler;

import lombok.RequiredArgsConstructor;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class ConsultDocFileVerificationDetailsApiController implements ConsultDocFileVerificationDetailsApi {

    @Autowired
    private ConsultDocFileVerificationDetailsHandler consultDocFileVerificationDetailsHandler;

    @Override
    public ResponseEntity<ConsultDocFileVerificationDetailsResponseDTO> _consultDocFileVerificationDetails(
            UUID docFileVerificationId) {
        try {
            ConsultDocFileVerificationDetailsOutputDTO outputDTO = consultDocFileVerificationDetailsHandler
                    .consultDocFileVerificationDetails(docFileVerificationId);
            ConsultDocFileVerificationDetailsResponseDTO responseDTO = DocFileVerificationAppMapper.INSTANCE
                    .map(outputDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } catch (IllegalArgumentException exception) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
