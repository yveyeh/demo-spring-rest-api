package com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model;

import com.didi.quizapp.identities.validations.core.shared.model.BaseModel;
import com.didi.quizapp.identities.validations.shared.enums.DocFileStatus;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.format.annotation.DateTimeFormat;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
public class DocFileVerificationModel extends BaseModel {

    @Builder.Default
    private boolean callMade = false;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime verifiedAt;

    @Enumerated(EnumType.STRING)
    private DocFileStatus verificationStatus;

    private UUID verifiedBy;

    private UUID docFileId;

    private UUID rejectReasonId;

}
