package com.didi.quizapp.identities.validations.infrastructure.docfile_feature.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.didi.quizapp.identities.validations.core.docfile_feature.shared.model.DocFileModel;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.repository.DocFileRepositoryPort;
import com.didi.quizapp.identities.validations.infrastructure.docfile_feature.entity.DocFileEntity;
import com.didi.quizapp.identities.validations.infrastructure.docfile_feature.mapper.DocFileInfraMapper;

import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Repository
public class DocFileRepositoryAdapter implements DocFileRepositoryPort {

    @Autowired
    private DocFileRepository docFileRepository;

    // public DocFileRepositoryAdapter(DocFileRepository docFileRepository) {
    //     this.docFileRepository = docFileRepository;
    // }

    @Override
    public DocFileModel saveAndFlush(DocFileModel entity) {
        return DocFileInfraMapper.INSTANCE.map(
                docFileRepository.saveAndFlush(
                        DocFileInfraMapper.INSTANCE.map(entity)
                ));
    }

    @Override
    public DocFileModel getById(UUID uuid) {
        return DocFileInfraMapper.INSTANCE.map(
                docFileRepository.getReferenceById(
                        uuid
                ));
    }

    @Override
    public DocFileModel save(DocFileModel entity) {
        DocFileEntity innerMapper = DocFileInfraMapper.INSTANCE.map(entity);
        DocFileEntity action = docFileRepository.save(innerMapper);
        DocFileModel outerMapper = DocFileInfraMapper.INSTANCE.map(action);
        return outerMapper;
    }

    @Override
    public Optional<DocFileModel> findById(@NotNull UUID uuid) {
        return Optional.of(DocFileInfraMapper.INSTANCE.map(
                docFileRepository.findById(uuid).get()));
    }

    @Override
    public boolean existsById(UUID uuid) {
        return docFileRepository.existsById(uuid);
    }

    @Override
    public List<DocFileModel> findAll() {
        return DocFileInfraMapper.INSTANCE.map(docFileRepository.findAll());
    }

    @Override
    public long count() {
        return docFileRepository.count();
    }

    @Override
    public void delete(DocFileModel model) {
        docFileRepository.delete(DocFileInfraMapper.INSTANCE.map(model));
    }

    @Override
    public void deleteById(UUID uuid) {
        docFileRepository.deleteById(uuid);
    }

    @Override
    public Page<DocFileModel> findAll(Pageable pageable) {
        Page<DocFileEntity> docFileEntityPage = docFileRepository.findAll(pageable);

        List<DocFileModel> docFileModels = DocFileInfraMapper.INSTANCE.map(docFileEntityPage.getContent());

        return new PageImpl<>(docFileModels, pageable, count());
    }

    @Override
    public Page<DocFileModel> findByDocFileId(Pageable pageable, UUID docFileId) {
        return null; // TODO: Look into separating concerns right at the level of BaseRepository
    }
}
