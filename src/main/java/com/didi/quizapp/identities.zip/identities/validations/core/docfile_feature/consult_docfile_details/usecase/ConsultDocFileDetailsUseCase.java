package com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_details.usecase;
import java.util.UUID;

import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_details.dto.ConsultDocFileDetailsOutputDTO;

public interface ConsultDocFileDetailsUseCase {
    ConsultDocFileDetailsOutputDTO consultDocFileDetails(UUID docFileId);
}
