package com.didi.quizapp.identities.validations.core.docfile_verification_feature.delete_docfile_verification.handler;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.delete_docfile_verification.usecase.DeleteDocFileVerificationUseCase;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model.DocFileVerificationModel;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.repository.DocFileVerificationRepositoryPort;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class DeleteDocFileVerificationHandler implements DeleteDocFileVerificationUseCase {

    @Autowired
    private DocFileVerificationRepositoryPort docFileVerificationRepositoryPort;

    public DeleteDocFileVerificationHandler(DocFileVerificationRepositoryPort docFileVerificationRepositoryPort) {
        this.docFileVerificationRepositoryPort = docFileVerificationRepositoryPort;
    }

    @Override
    public void deleteDocFileVerificationDetails(UUID docFileVerificationId) {

        DocFileVerificationModel docFileVerificationModel = docFileVerificationRepositoryPort
                .findById(docFileVerificationId)
                .orElseThrow(() -> new IllegalArgumentException("Not found"));

        docFileVerificationRepositoryPort.delete(docFileVerificationModel);
    }
}
