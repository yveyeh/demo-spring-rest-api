package com.didi.quizapp.identities.validations.core.docfile_feature.shared.repository;

import com.didi.quizapp.identities.validations.core.docfile_feature.shared.model.DocFileModel;
import com.didi.quizapp.identities.validations.core.shared.repository.BaseRepository;

public interface DocFileRepositoryPort extends BaseRepository<DocFileModel> {
    
}
