package com.didi.quizapp.identities.validations.core.shared.utils;

import com.didi.quizapp.identities.validations.core.shared.dto.MetaDataDTO;
import org.springframework.data.domain.Page;

public class Utils {
    public static MetaDataDTO setMetaDataFromEntityPage(Page<?> entity) {
        MetaDataDTO metaDataDTO = new MetaDataDTO();
        metaDataDTO.setCount(entity.getContent().size());
        metaDataDTO.setPage(entity.getNumber());
        metaDataDTO.setSize(entity.getSize());
        metaDataDTO.setTotalCount(entity.getNumberOfElements());
        metaDataDTO.setTotalPages(entity.getTotalPages());
        return metaDataDTO;
    }
}
