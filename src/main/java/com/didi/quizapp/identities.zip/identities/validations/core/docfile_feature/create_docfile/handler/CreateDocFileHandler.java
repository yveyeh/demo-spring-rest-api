package com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.handler;

import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.dto.CreateDocFileInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.dto.CreateDocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.usecase.CreateDocFileUseCase;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.dto.DocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.mapper.DocFileCoreMapper;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.model.DocFileModel;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.repository.DocFileRepositoryPort;

import org.springframework.beans.factory.annotation.Autowired;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@RequiredArgsConstructor
@Service
public class CreateDocFileHandler implements CreateDocFileUseCase {

    @Autowired
    private DocFileRepositoryPort docFileRepositoryPort;

    // public CreateDocFileHandler(DocFileRepositoryPort docFileRepositoryPort) {
    //     this.docFileRepositoryPort = docFileRepositoryPort;
    // }
        
    @Override
    public CreateDocFileOutputDTO createDocFile(CreateDocFileInputDTO docFileInputDTO) {

        long startTime = System.currentTimeMillis();

        DocFileModel docFileModel = docFileRepositoryPort.save(DocFileCoreMapper.INSTANCE.map(docFileInputDTO));
        DocFileOutputDTO docFileOutputDTO = DocFileCoreMapper.INSTANCE.map(docFileModel);
        CreateDocFileOutputDTO createDocFileOutputDTO = new CreateDocFileOutputDTO();
        createDocFileOutputDTO.setData(docFileOutputDTO);

        long endTime = System.currentTimeMillis();

        createDocFileOutputDTO.setElapsedTime(BigDecimal.valueOf(endTime - startTime));
        return createDocFileOutputDTO;

    }
}
