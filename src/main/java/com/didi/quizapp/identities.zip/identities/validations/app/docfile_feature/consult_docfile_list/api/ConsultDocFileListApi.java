package com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_list.api;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_list.dto.ConsultDocFileListResponseDTO;
import com.didi.quizapp.identities.validations.shared.ResponseErrorDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@Validated
@Tag(name = "ConsultDocFileList", description = "Endpoint feature to consult files list")
public interface ConsultDocFileListApi {

    /**
     * GET /iam/identities/validations/docfiles : Consult DocFile List
     * Consult the list of files paginated.
     *
     * @param page The page number (optional, default to 1)
     * @param size The page size (optional, default to 10)
     * @return Returned when everything work (status code 200)
     *         or Returned when an error occur (status code 200)
     */
    @Operation(
        operationId = "consultDocFileList",
        summary = "Consult DocFile List",
        description = "Consult the list of files paginated.",
        tags = { "ConsultDocFileList" },
        responses = {
            @ApiResponse(responseCode = "200", description = "Returned when everything work", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = ConsultDocFileListResponseDTO.class))
            }),
            @ApiResponse(responseCode = "default", description = "Returned when an error occur", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseErrorDTO.class))
            })
        }
    )
    @RequestMapping(
        method = RequestMethod.GET,
        value = "/iam/identities/validations/docfiles",
        produces = { "application/json" }
    )
    
    ResponseEntity<ConsultDocFileListResponseDTO> _consultDocFileList(
        @Min(1) @Parameter(name = "page", description = "The page number", in = ParameterIn.QUERY) @Valid @RequestParam(value = "page", required = false, defaultValue = "1") Integer page,
        @Min(1) @Max(100) @Parameter(name = "size", description = "The page size", in = ParameterIn.QUERY) @Valid @RequestParam(value = "size", required = false, defaultValue = "10") Integer size
    );

}
