package com.didi.quizapp.identities.validations.app.docfile_verification_feature.delete_docfile_verification.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.didi.quizapp.identities.validations.app.docfile_verification_feature.delete_docfile_verification.api.DeleteDocFileVerificationApi;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.delete_docfile_verification.handler.DeleteDocFileVerificationHandler;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
public class DeleteDocFileVerificationApiController implements DeleteDocFileVerificationApi {

    @Autowired
    private DeleteDocFileVerificationHandler deleteDocFileVerificationHandler;

    // public DeleteDocFileVerificationApiController(DeleteDocFileVerificationHandler deleteDocFileVerificationHandler) {
    //     this.deleteDocFileVerificationHandler = deleteDocFileVerificationHandler;
    // }

    @Override
    public ResponseEntity<String> _deleteDocFileVerificationDetails(UUID docFileVerificationId) {
        try {
            deleteDocFileVerificationHandler.deleteDocFileVerificationDetails(docFileVerificationId);
            return new ResponseEntity<String>("Successfully deleted file", HttpStatus.NO_CONTENT);
        } catch (IllegalArgumentException exception) {
            return new ResponseEntity<String>("An error occured while trying to delete file verification", HttpStatus.NOT_FOUND);
        }
    }

}
