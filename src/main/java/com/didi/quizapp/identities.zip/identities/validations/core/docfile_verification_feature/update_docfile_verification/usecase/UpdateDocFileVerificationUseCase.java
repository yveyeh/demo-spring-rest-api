package com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.usecase;

import java.util.UUID;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationOutputDTO;

public interface UpdateDocFileVerificationUseCase {
    UpdateDocFileVerificationOutputDTO update(UUID docFileVerificationId,
            UpdateDocFileVerificationInputDTO docFileVerificationInputDTO);
}
