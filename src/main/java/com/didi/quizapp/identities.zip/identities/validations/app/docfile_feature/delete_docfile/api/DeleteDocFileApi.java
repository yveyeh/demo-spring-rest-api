package com.didi.quizapp.identities.validations.app.docfile_feature.delete_docfile.api;

import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.didi.quizapp.identities.validations.shared.ResponseErrorDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@Validated
@Tag(name = "DeleteDocFile", description = "Endpoint feature to delete a doc file")
public interface DeleteDocFileApi {

    /**
     * DELETE /iam/identities/validations/docfiles/{docFileId} : Delete DocFile Details
     * Delete the details of a DocFile identified by its ID.
     *
     * @param docFileId Unique identifier (UUID) of the file to delete (required)
     * @return This response is returned when operation succeeded (status code 204)
     *         or Returned when an error occur (status code 404)
     */
    @Operation(
        operationId = "deleteDocFileDetails",
        summary = "Delete DocFile Details",
        description = "Delete the details of a DocFile identified by it ID.",
        tags = { "DeleteDocFile" },
        responses = {
            @ApiResponse(responseCode = "204", description = "This response is returned when operation succeeded"),
            @ApiResponse(responseCode = "default", description = "Returned when an error occurs", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseErrorDTO.class))
            })
        }
    )
    @RequestMapping(
        method = RequestMethod.DELETE,
        value = "/iam/identities/validations/docfiles/{docFileId}",
        produces = { "application/json" }
    )
    
    ResponseEntity<String> _deleteDocFileDetails(
        @Parameter(name = "docFileId", description = "Unique identifier (UUID) of the doc file to delete", required = true, in = ParameterIn.PATH) @PathVariable("docFileId") UUID docFileId
    );

}
