package com.didi.quizapp.identities.validations.app.docfile_feature.create_docfile.controller;

import com.didi.quizapp.identities.validations.app.docfile_feature.create_docfile.api.CreateDocFileApi;
import com.didi.quizapp.identities.validations.app.docfile_feature.create_docfile.dto.CreateDocFileRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.create_docfile.dto.CreateDocFileResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.shared.mapper.DocFileAppMapper;
import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.dto.CreateDocFileInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.dto.CreateDocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.handler.CreateDocFileHandler;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class CreateDocFileApiController implements CreateDocFileApi {

    @Autowired
    private CreateDocFileHandler createDocFileHandler;

    // public CreateDocFileApiController(CreateDocFileHandler createDocFileHandler) {
    //     this.createDocFileHandler = createDocFileHandler;
    // }

    @Override
    public ResponseEntity<CreateDocFileResponseDTO> _createDocFile(CreateDocFileRequestDTO createDocFileRequestDTO) {
        try {
            CreateDocFileInputDTO requestDTO = DocFileAppMapper.INSTANCE.map(createDocFileRequestDTO);
            CreateDocFileOutputDTO outputDTO = createDocFileHandler.createDocFile(requestDTO);
            CreateDocFileResponseDTO responseDTO = DocFileAppMapper.INSTANCE.map(outputDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } catch (IllegalArgumentException exception) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
