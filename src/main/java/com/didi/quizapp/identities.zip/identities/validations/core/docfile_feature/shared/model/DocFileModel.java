package com.didi.quizapp.identities.validations.core.docfile_feature.shared.model;

import com.didi.quizapp.identities.validations.core.shared.model.BaseModel;
import com.didi.quizapp.identities.validations.shared.enums.DocFileStatus;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.format.annotation.DateTimeFormat;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
public class DocFileModel extends BaseModel {

    private String description;

    @Builder.Default
    private boolean verified = false;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime verifiedAt;

    @Enumerated(EnumType.STRING)
    private DocFileStatus verificationStatus;

    private UUID verifiedBy;

    private UUID docFileTypeId;

    private UUID idDocId;

}
