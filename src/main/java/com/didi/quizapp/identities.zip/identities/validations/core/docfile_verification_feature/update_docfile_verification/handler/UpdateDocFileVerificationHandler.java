package com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.handler;

import java.math.BigDecimal;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.dto.DocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.mapper.DocFileVerificationCoreMapper;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model.DocFileVerificationModel;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.repository.DocFileVerificationRepositoryPort;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.usecase.UpdateDocFileVerificationUseCase;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class UpdateDocFileVerificationHandler implements UpdateDocFileVerificationUseCase {

        @Autowired
        private DocFileVerificationRepositoryPort docFileVerificationRepositoryPort;

        @Override
        public UpdateDocFileVerificationOutputDTO update(UUID docFileVerificationId,
                        UpdateDocFileVerificationInputDTO docFileVerificationInputDTO) {
                long startTime = System.currentTimeMillis();

                DocFileVerificationModel docFileVerificationModel = docFileVerificationRepositoryPort
                                .findById(docFileVerificationId)
                                .orElseThrow(() -> new IllegalArgumentException("DocFileVerification not found"));

                DocFileVerificationCoreMapper.INSTANCE
                                .updateDocFileVerificationModelFromUpdateDocFileVerificationInputDTO(
                                                docFileVerificationInputDTO, docFileVerificationModel);

                docFileVerificationRepositoryPort.saveAndFlush(docFileVerificationModel);

                UpdateDocFileVerificationOutputDTO updateDocFileVerificationOutputDTO = new UpdateDocFileVerificationOutputDTO();

                DocFileVerificationOutputDTO docFileVerificationOutputDTO = DocFileVerificationCoreMapper.INSTANCE
                                .map(docFileVerificationModel);

                updateDocFileVerificationOutputDTO.setData(docFileVerificationOutputDTO);

                long endTime = System.currentTimeMillis();

                updateDocFileVerificationOutputDTO.setElapsedTime(BigDecimal.valueOf(endTime - startTime));

                return updateDocFileVerificationOutputDTO;

        }

}
