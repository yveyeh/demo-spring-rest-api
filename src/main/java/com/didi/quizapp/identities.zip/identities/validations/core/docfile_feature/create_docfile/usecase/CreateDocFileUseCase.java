package com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.usecase;

import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.dto.CreateDocFileInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.dto.CreateDocFileOutputDTO;

public interface CreateDocFileUseCase {

    CreateDocFileOutputDTO createDocFile(CreateDocFileInputDTO docFileInputDTO);

}
