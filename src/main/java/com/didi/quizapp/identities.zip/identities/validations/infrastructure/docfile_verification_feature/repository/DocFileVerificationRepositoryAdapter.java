package com.didi.quizapp.identities.validations.infrastructure.docfile_verification_feature.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model.DocFileVerificationModel;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.repository.DocFileVerificationRepositoryPort;
import com.didi.quizapp.identities.validations.infrastructure.docfile_verification_feature.entity.DocFileVerificationEntity;
import com.didi.quizapp.identities.validations.infrastructure.docfile_verification_feature.mapper.DocFileVerificationInfraMapper;

import jakarta.validation.constraints.NotNull;

@Repository
public class DocFileVerificationRepositoryAdapter implements DocFileVerificationRepositoryPort {

    @Autowired
    private DocFileVerificationRepository docFileVerificationRepository;

    // public DocFileVerificationRepositoryAdapter(DocFileVerificationRepository docFileVerificationRepository) {
    //     this.docFileVerificationRepository = docFileVerificationRepository;
    // }

    @Override
    public DocFileVerificationModel saveAndFlush(DocFileVerificationModel entity) {
        return DocFileVerificationInfraMapper.INSTANCE.map(
                docFileVerificationRepository.saveAndFlush(
                        DocFileVerificationInfraMapper.INSTANCE.map(entity)));
    }

    @Override
    public DocFileVerificationModel getById(UUID uuid) {
        return DocFileVerificationInfraMapper.INSTANCE.map(
                docFileVerificationRepository.getReferenceById(
                        uuid));
    }

    @Override
    public DocFileVerificationModel save(DocFileVerificationModel entity) {
        DocFileVerificationEntity innerMapper = DocFileVerificationInfraMapper.INSTANCE.map(entity);
        DocFileVerificationEntity action = docFileVerificationRepository.save(innerMapper);
        DocFileVerificationModel outerMapper = DocFileVerificationInfraMapper.INSTANCE.map(action);
        return outerMapper;
    }

    @Override
    public Optional<DocFileVerificationModel> findById(@NotNull UUID uuid) {
        return Optional.of(DocFileVerificationInfraMapper.INSTANCE.map(
                docFileVerificationRepository.findById(
                        uuid).get()));
    }

    @Override
    public boolean existsById(UUID uuid) {
        return docFileVerificationRepository.existsById(uuid);
    }

    @Override
    public List<DocFileVerificationModel> findAll() {
        return DocFileVerificationInfraMapper.INSTANCE.map(docFileVerificationRepository.findAll());
    }

    @Override
    public long count() {
        return docFileVerificationRepository.count();
    }

    @Override
    public void delete(DocFileVerificationModel model) {
        docFileVerificationRepository.delete(DocFileVerificationInfraMapper.INSTANCE.map(model));
    }

    @Override
    public void deleteById(UUID uuid) {
        docFileVerificationRepository.deleteById(uuid);
    }

    @Override
    public Page<DocFileVerificationModel> findAll(Pageable pageable) {
        Page<DocFileVerificationEntity> docFileVerificationEntityPage = docFileVerificationRepository.findAll(pageable);

        List<DocFileVerificationModel> docFileVerificationModels = DocFileVerificationInfraMapper.INSTANCE
                .map(docFileVerificationEntityPage.getContent());

        return new PageImpl<>(docFileVerificationModels, pageable, count());
    }

    @Override
    // @Query(value = "SELECT * FROM doc_file_verifications d WHERE d.doc_file_id=:docFileId ORDER BY d.created_at DESC", nativeQuery = true)
    public Page<DocFileVerificationModel> findByDocFileId(Pageable pageable, UUID docFileId) {
        Page<DocFileVerificationEntity> docFileVerificationEntityPage = docFileVerificationRepository.findByDocFileId(pageable, docFileId);

        List<DocFileVerificationModel> docFileVerificationModels = DocFileVerificationInfraMapper.INSTANCE
                .map(docFileVerificationEntityPage.getContent());

        return new PageImpl<>(docFileVerificationModels, pageable, count());
    }
}
