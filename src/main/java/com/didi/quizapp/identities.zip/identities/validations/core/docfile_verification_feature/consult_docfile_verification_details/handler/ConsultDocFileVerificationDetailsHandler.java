package com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_details.handler;

import java.math.BigDecimal;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_details.dto.ConsultDocFileVerificationDetailsOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_details.usecase.ConsultDocFileVerificationDetailsUseCase;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.dto.DocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.mapper.DocFileVerificationCoreMapper;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model.DocFileVerificationModel;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.repository.DocFileVerificationRepositoryPort;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class ConsultDocFileVerificationDetailsHandler implements ConsultDocFileVerificationDetailsUseCase {

    @Autowired
    private DocFileVerificationRepositoryPort docFileVerificationRepositoryPort;

    @Override
    public ConsultDocFileVerificationDetailsOutputDTO consultDocFileVerificationDetails(UUID docFileVerificationId) {

        long startTime = System.currentTimeMillis();

        DocFileVerificationModel docFileVerificationModel = docFileVerificationRepositoryPort
                .findById(docFileVerificationId)
                .orElseThrow(() -> new IllegalArgumentException("DocFileVerification not found"));

        ConsultDocFileVerificationDetailsOutputDTO consultDocFileVerificationDetailsOutputDTO = new ConsultDocFileVerificationDetailsOutputDTO();

        DocFileVerificationOutputDTO docFileVerificationOutputDTO = DocFileVerificationCoreMapper.INSTANCE
                .map(docFileVerificationModel);

        consultDocFileVerificationDetailsOutputDTO.setData(docFileVerificationOutputDTO);

        long endTime = System.currentTimeMillis();

        consultDocFileVerificationDetailsOutputDTO.setElapsedTime(BigDecimal.valueOf(endTime - startTime));

        return consultDocFileVerificationDetailsOutputDTO;
    }

}
