package com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_details.controller;

import com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_details.api.ConsultDocFileDetailsApi;
import com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_details.dto.ConsultDocFileDetailsResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.shared.mapper.DocFileAppMapper;
import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_details.dto.ConsultDocFileDetailsOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_details.handler.ConsultDocFileDetailsHandler;

import lombok.RequiredArgsConstructor;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class ConsultDocFileDetailsApiController  implements ConsultDocFileDetailsApi{

    @Autowired
    private ConsultDocFileDetailsHandler consultDocFileDetailsHandler;

    // public ConsultDocFileDetailsApiController(ConsultDocFileDetailsHandler consultDocFileDetailsHandler) {
    //     this.consultDocFileDetailsHandler = consultDocFileDetailsHandler;
    // }

    @Override
    public ResponseEntity<ConsultDocFileDetailsResponseDTO> _consultDocFileDetails(UUID docFile) {
        try {
            ConsultDocFileDetailsOutputDTO outputDTO = consultDocFileDetailsHandler.consultDocFileDetails(docFile);
            ConsultDocFileDetailsResponseDTO responseDTO = DocFileAppMapper.INSTANCE.map(outputDTO);
            return new ResponseEntity<ConsultDocFileDetailsResponseDTO>(responseDTO, HttpStatus.OK);
            // return new ResponseEntity<>(
                // CareerAppMapper.INSTANCE.map(
                    // consultCareerDetailsHandler.consultCareerDetails(careerId)), 
                    // HttpStatus.OK
                // );
            
            // return new ResponseEntity<>(
            //         DocFileAppMapper.INSTANCE.map(
            //                 consultDocFileDetailsHandler.consultDocFileDetails(
            //                         DocFileAppMapper.INSTANCE.map(consultDocFileDetailsRequestDTO)
            //                 )
            //         ), HttpStatus.OK);
        } catch (IllegalArgumentException exception) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
