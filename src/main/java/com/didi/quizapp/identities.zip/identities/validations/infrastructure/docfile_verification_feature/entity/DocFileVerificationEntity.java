package com.didi.quizapp.identities.validations.infrastructure.docfile_verification_feature.entity;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.format.annotation.DateTimeFormat;

import com.didi.quizapp.identities.validations.shared.enums.DocFileStatus;
import com.didi.quizapp.identities.validations.infrastructure.shared.entity.BaseEntity;

import jakarta.persistence.*;
// import jakarta.persistence.Entity;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@SuperBuilder
@Table(name = "doc_file_verifications")
public class DocFileVerificationEntity extends BaseEntity {

    public static final DocFileStatus DEFAULT_STATUS = DocFileStatus.MISSING;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    @Column(name = "verified_at")
    private OffsetDateTime verifiedAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "verification_status")
    private DocFileStatus verificationStatus;

    @Builder.Default
    @Column(name = "call_made")
    private boolean callMade = false;

    // @EqualsAndHashCode.Exclude
    // @ManyToOne
    // @JoinColumn(name = "user_id")
    @Column(name = "verified_by")
    private UUID verifiedBy;

    // @EqualsAndHashCode.Exclude
    // @ManyToOne
    // @JoinColumn(name = "doc_file_id")
    @Column(name = "doc_file_id")
    private UUID docFileId;

    // @EqualsAndHashCode.Exclude
    // @ManyToOne
    // @JoinColumn(name = "id_doc_id")
    @Column(name = "reject_reason_id")
    private UUID rejectReasonId;

}
