package com.didi.quizapp.identities.validations.app.docfile_feature.delete_docfile.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.didi.quizapp.identities.validations.app.docfile_feature.delete_docfile.api.DeleteDocFileApi;
import com.didi.quizapp.identities.validations.core.docfile_feature.delete_docfile.handler.DeleteDocFileHandler;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
public class DeleteDocFileApiController implements DeleteDocFileApi {

    @Autowired
    private DeleteDocFileHandler deleteDocFileHandler;

    // public DeleteDocFileApiController(DeleteDocFileHandler deleteDocFileHandler) {
    //     this.deleteDocFileHandler = deleteDocFileHandler;
    // }

    @Override
    public ResponseEntity<String> _deleteDocFileDetails(UUID docFileId) {
        try {
            deleteDocFileHandler.deleteDocFileDetails(docFileId);
            return new ResponseEntity<String>("Successfully deleted file", HttpStatus.NO_CONTENT);
        } catch (IllegalArgumentException exception) {
            return new ResponseEntity<String>("An error occured while trying to delete file", HttpStatus.NOT_FOUND);
        }
    }

}
