package com.didi.quizapp.identities.validations.core.docfile_feature.delete_docfile.usecase;

import java.util.UUID;

public interface DeleteDocFileUseCase {
    void deleteDocFileDetails(UUID docFileId);
}
