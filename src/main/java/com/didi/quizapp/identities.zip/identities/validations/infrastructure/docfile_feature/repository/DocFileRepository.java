package com.didi.quizapp.identities.validations.infrastructure.docfile_feature.repository;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.didi.quizapp.identities.validations.infrastructure.docfile_feature.entity.DocFileEntity;

public interface DocFileRepository extends JpaRepository<DocFileEntity, UUID> {

}
