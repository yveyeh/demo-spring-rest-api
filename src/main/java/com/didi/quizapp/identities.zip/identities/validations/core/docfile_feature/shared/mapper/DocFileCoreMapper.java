package com.didi.quizapp.identities.validations.core.docfile_feature.shared.mapper;

import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.dto.CreateDocFileInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.dto.DocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.model.DocFileModel;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.dto.UpdateDocFileInputDTO;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface DocFileCoreMapper {
    DocFileCoreMapper INSTANCE = Mappers.getMapper(DocFileCoreMapper.class);

    DocFileOutputDTO map(DocFileModel docFileModel);

    List<DocFileOutputDTO> map(List<DocFileModel> docFileModelList);

    DocFileModel map(CreateDocFileInputDTO docFileInputDTO);

    void updateDocFileModelFromUpdateDocFileInputDTO(UpdateDocFileInputDTO docFileInputDTO, @MappingTarget DocFileModel docFileModel);
}