package com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_list.handler;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_list.dto.ConsultDocFileListOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_list.usecase.ConsultDocFileListUseCase;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.dto.DocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.mapper.DocFileCoreMapper;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.model.DocFileModel;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.repository.DocFileRepositoryPort;
import com.didi.quizapp.identities.validations.core.shared.dto.MetaDataDTO;
import com.didi.quizapp.identities.validations.core.shared.utils.Utils;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class ConsultDocFileListHandler implements ConsultDocFileListUseCase {

    @Autowired
    private DocFileRepositoryPort docFileRepositoryPort;

    // public ConsultDocFileListHandler(DocFileRepositoryPort docFileRepositoryPort) {
    //     this.docFileRepositoryPort = docFileRepositoryPort;
    // }

    @Override
    public ConsultDocFileListOutputDTO consultDocFileList(Integer page, Integer size) {
        //
        long startTime = System.currentTimeMillis();

        // DocFileModel
        Pageable pageable = PageRequest.of(page - 1, size);

        Page<DocFileModel> docFileModelPage = docFileRepositoryPort.findAll(pageable);

        // List<DocFileModel> docFileModelList = docFileRepositoryPort.findAll();

        // Meta data
        MetaDataDTO metaDataDTO = Utils.setMetaDataFromEntityPage(docFileModelPage);

        ConsultDocFileListOutputDTO consultDocFileListOutputDTO = new ConsultDocFileListOutputDTO();

        consultDocFileListOutputDTO.setMetaData(metaDataDTO);

        // Data
        List<DocFileOutputDTO> docFileOutputDTOs = DocFileCoreMapper.INSTANCE.map(docFileModelPage.getContent());

        consultDocFileListOutputDTO.setData(docFileOutputDTOs);

        //
        long endTime = System.currentTimeMillis();

        consultDocFileListOutputDTO.setElapsedTime(BigDecimal.valueOf(endTime - startTime));

        // Output DTO
        return consultDocFileListOutputDTO;
    }

}
