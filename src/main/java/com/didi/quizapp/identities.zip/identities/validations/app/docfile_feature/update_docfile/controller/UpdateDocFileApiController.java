package com.didi.quizapp.identities.validations.app.docfile_feature.update_docfile.controller;

import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.didi.quizapp.identities.validations.app.docfile_feature.shared.mapper.DocFileAppMapper;
import com.didi.quizapp.identities.validations.app.docfile_feature.update_docfile.api.UpdateDocFileApi;
import com.didi.quizapp.identities.validations.app.docfile_feature.update_docfile.dto.UpdateDocFileRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.update_docfile.dto.UpdateDocFileResponseDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.dto.UpdateDocFileInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.dto.UpdateDocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.handler.UpdateDocFileHandler;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
public class UpdateDocFileApiController implements UpdateDocFileApi {

    @Autowired
    private UpdateDocFileHandler updateDocFileHandler;

    @Override
    public ResponseEntity<UpdateDocFileResponseDTO> _updateDocFileDetails(UUID docFileId, UpdateDocFileRequestDTO updateDocFileRequestDTO) {
        try {
            UpdateDocFileInputDTO inputDTO = DocFileAppMapper.INSTANCE.map(updateDocFileRequestDTO);
            UpdateDocFileOutputDTO outputDTO = updateDocFileHandler.update(docFileId, inputDTO);
            UpdateDocFileResponseDTO responseDTO = DocFileAppMapper.INSTANCE.map(outputDTO);
            return new ResponseEntity<UpdateDocFileResponseDTO>(responseDTO, HttpStatus.OK);
        } catch (IllegalArgumentException exception) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
