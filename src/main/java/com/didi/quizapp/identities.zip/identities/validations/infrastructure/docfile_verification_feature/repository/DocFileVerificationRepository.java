package com.didi.quizapp.identities.validations.infrastructure.docfile_verification_feature.repository;

import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.didi.quizapp.identities.validations.infrastructure.docfile_verification_feature.entity.DocFileVerificationEntity;

public interface DocFileVerificationRepository extends JpaRepository<DocFileVerificationEntity, UUID> {

    Page<DocFileVerificationEntity> findByDocFileId(Pageable pageable, UUID docFileId);

}
