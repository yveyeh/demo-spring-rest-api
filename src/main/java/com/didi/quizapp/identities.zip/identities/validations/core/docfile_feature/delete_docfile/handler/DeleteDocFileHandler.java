package com.didi.quizapp.identities.validations.core.docfile_feature.delete_docfile.handler;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.didi.quizapp.identities.validations.core.docfile_feature.delete_docfile.usecase.DeleteDocFileUseCase;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.model.DocFileModel;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.repository.DocFileRepositoryPort;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class DeleteDocFileHandler implements DeleteDocFileUseCase {

    @Autowired
    private DocFileRepositoryPort docFileRepositoryPort;

    // public DeleteDocFileHandler(DocFileRepositoryPort docFileRepositoryPort) {
    //     this.docFileRepositoryPort = docFileRepositoryPort;
    // }

    @Override
    public void deleteDocFileDetails(UUID docFileId) {

        DocFileModel docFileModel = docFileRepositoryPort.findById(docFileId)
                .orElseThrow(() -> new IllegalArgumentException("File not found"));

        docFileRepositoryPort.delete(docFileModel);
    }
}
