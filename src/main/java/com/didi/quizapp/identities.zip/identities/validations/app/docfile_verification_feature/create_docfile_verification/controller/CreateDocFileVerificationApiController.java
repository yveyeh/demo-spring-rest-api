package com.didi.quizapp.identities.validations.app.docfile_verification_feature.create_docfile_verification.controller;

import com.didi.quizapp.identities.validations.app.docfile_verification_feature.create_docfile_verification.api.CreateDocFileVerificationApi;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.shared.mapper.DocFileVerificationAppMapper;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.handler.CreateDocFileVerificationHandler;

import lombok.RequiredArgsConstructor;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class CreateDocFileVerificationApiController implements CreateDocFileVerificationApi {

    @Autowired
    private CreateDocFileVerificationHandler createDocFileVerificationHandler;

    // public CreateDocFileVerificationApiController(CreateDocFileVerificationHandler createDocFileVerificationHandler) {
    //     this.createDocFileVerificationHandler = createDocFileVerificationHandler;
    // }

    @Override
    public ResponseEntity<CreateDocFileVerificationResponseDTO> _createDocFileVerification(UUID docFileId, CreateDocFileVerificationRequestDTO createDocFileVerificationRequestDTO) {
        try {
            CreateDocFileVerificationInputDTO requestDTO = DocFileVerificationAppMapper.INSTANCE.map(createDocFileVerificationRequestDTO);
            CreateDocFileVerificationOutputDTO outputDTO = createDocFileVerificationHandler.createDocFileVerification(docFileId, requestDTO);
            CreateDocFileVerificationResponseDTO responseDTO = DocFileVerificationAppMapper.INSTANCE.map(outputDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } catch (IllegalArgumentException exception) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
