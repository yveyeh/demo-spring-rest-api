package com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_list.api;

import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_list.dto.ConsultDocFileVerificationListResponseDTO;
import com.didi.quizapp.identities.validations.shared.ResponseErrorDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@Validated
@Tag(name = "ConsultDocFileVerificationList", description = "Endpoint feature to consult files list")
public interface ConsultDocFileVerificationListApi {

    /**
     * GET /iam/identities/validations/docfiles/{docFileId}/verifications : Consult DocFileVerification List
     * Consult the list of files paginated.
     *
     * @param page The page number (optional, default to 1)
     * @param size The page size (optional, default to 10)
     * @return Returned when everything work (status code 200)
     *         or Returned when an error occur (status code 200)
     */
    @Operation(
        operationId = "consultDocFileVerificationList",
        summary = "Consult DocFileVerification List",
        description = "Consult the list of files paginated.",
        tags = { "ConsultDocFileVerificationList" },
        responses = {
            @ApiResponse(responseCode = "200", description = "Returned when everything work", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = ConsultDocFileVerificationListResponseDTO.class))
            }),
            @ApiResponse(responseCode = "default", description = "Returned when an error occur", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseErrorDTO.class))
            })
        }
    )
    @RequestMapping(
        method = RequestMethod.GET,
        value = "/iam/identities/validations/docfiles/{docFileId}/verifications",
        produces = { "application/json" }
    )
    
    ResponseEntity<ConsultDocFileVerificationListResponseDTO> _consultDocFileVerificationList(
        @Parameter(name = "docFileId", description = "Unique identifier (UUID) of the docfile for which to fetch verifications", required = true, in = ParameterIn.PATH) @PathVariable("docFileId") UUID docFileId,
        @Min(1) @Parameter(name = "page", description = "The page number", in = ParameterIn.QUERY) @Valid @RequestParam(value = "page", required = false, defaultValue = "1") Integer page,
        @Min(1) @Max(100) @Parameter(name = "size", description = "The page size", in = ParameterIn.QUERY) @Valid @RequestParam(value = "size", required = false, defaultValue = "10") Integer size
    );

}
