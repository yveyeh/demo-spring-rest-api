package com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.repository;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model.DocFileVerificationModel;
import com.didi.quizapp.identities.validations.core.shared.repository.BaseRepository;

public interface DocFileVerificationRepositoryPort extends BaseRepository<DocFileVerificationModel> {

}
