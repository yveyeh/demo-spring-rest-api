package com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_list.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_list.api.ConsultDocFileVerificationListApi;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_list.dto.ConsultDocFileVerificationListResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.shared.mapper.DocFileVerificationAppMapper;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_list.dto.ConsultDocFileVerificationListOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.consult_docfile_verification_list.handler.ConsultDocFileVerificationListHandler;

// import jakarta.validation.Valid;
// import jakarta.validation.constraints.Max;
// import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
public class ConsultDocFileVerificationListApiController implements ConsultDocFileVerificationListApi {

    @Autowired
    private ConsultDocFileVerificationListHandler consultDocFileVerificationListHandler;

    // public ConsultDocFileVerificationListApiController(ConsultDocFileVerificationListHandler consultDocFileVerificationListHandler) {
    //     this.consultDocFileVerificationListHandler = consultDocFileVerificationListHandler;
    // }

    @Override
    @GetMapping("/iam/identities/validations/docfiles/{docFileId}/verifications")
    public ResponseEntity<ConsultDocFileVerificationListResponseDTO> _consultDocFileVerificationList(@PathVariable("docFileId") UUID docFileId, Integer page, Integer size) {
        try {
            ConsultDocFileVerificationListOutputDTO outputDTO = consultDocFileVerificationListHandler.consultDocFileVerificationList(docFileId, page, size);
            ConsultDocFileVerificationListResponseDTO responseDTO = DocFileVerificationAppMapper.INSTANCE.map(outputDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}