package com.didi.quizapp.identities.validations.infrastructure.docfile_verification_feature.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.shared.model.DocFileVerificationModel;
import com.didi.quizapp.identities.validations.infrastructure.docfile_verification_feature.entity.DocFileVerificationEntity;

@Mapper
public interface DocFileVerificationInfraMapper {

    DocFileVerificationInfraMapper INSTANCE = Mappers.getMapper(DocFileVerificationInfraMapper.class);

    DocFileVerificationModel map(DocFileVerificationEntity docFileVerificationEntity);

    DocFileVerificationEntity map(DocFileVerificationModel docFileVerificationModel);

    List<DocFileVerificationModel> map(List<DocFileVerificationEntity> docFileVerificationEntities);

}
