package com.didi.quizapp.identities.validations.core.docfile_verification_feature.delete_docfile_verification.usecase;

import java.util.UUID;

public interface DeleteDocFileVerificationUseCase {
    void deleteDocFileVerificationDetails(UUID docFileVerificationId);
}
