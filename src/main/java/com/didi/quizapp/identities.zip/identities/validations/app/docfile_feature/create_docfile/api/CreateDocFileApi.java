package com.didi.quizapp.identities.validations.app.docfile_feature.create_docfile.api;

import com.didi.quizapp.identities.validations.app.docfile_feature.create_docfile.dto.CreateDocFileRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.create_docfile.dto.CreateDocFileResponseDTO;
import com.didi.quizapp.identities.validations.shared.ResponseErrorDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@Validated
@Tag(name = "CreateDocFile", description = "Endpoint feature to create a document")
public interface CreateDocFileApi {

    /**
     * POST /iam/identities/validations/docfiles : Create a document
     * As system runner, I can create a document
     *
     * @param createDocFileRequestDTO DocFile payload for creation operation (required)
     * @return This response is return when operation succeeded (status code 201)
     *         or Returned when an error occur (status code 200)
     */
    @Operation(
        operationId = "createDocFile",
        summary = "Create a document",
        description = "As system runner, I can create a document",
        tags = { "CreateDocFile" },
        responses = {
            @ApiResponse(responseCode = "201", description = "This response is return when operation succeeded", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = CreateDocFileResponseDTO.class))
            }),
            @ApiResponse(responseCode = "default", description = "Returned when an error occurs", content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseErrorDTO.class))
            })
        }
    )
    @RequestMapping(
        method = RequestMethod.POST,
        value = "/iam/identities/validations/docfiles",
        produces = { "application/json" },
        consumes = { "application/json" }
    )
    
    ResponseEntity<CreateDocFileResponseDTO> _createDocFile(
        @Valid 
        @RequestBody 
        @Parameter(name = "CreateDocFileRequestDTO", description = "DocFile payload for creation operation", required = true) 
        CreateDocFileRequestDTO createDocFileRequestDTO
    );

}
