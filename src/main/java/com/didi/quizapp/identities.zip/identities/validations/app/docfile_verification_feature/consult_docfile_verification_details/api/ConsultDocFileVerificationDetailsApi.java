package com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_details.api;

import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.didi.quizapp.identities.validations.app.docfile_verification_feature.consult_docfile_verification_details.dto.ConsultDocFileVerificationDetailsResponseDTO;
import com.didi.quizapp.identities.validations.shared.ResponseErrorDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

public interface ConsultDocFileVerificationDetailsApi {

    /**
     * GET /iam/identities/validations/docfile/verifications/{id}
     * : Consult DocFileVerification Details
     * Consult the details of a DocFileVerification identified by it ID.
     *
     * @param id Unique identifier (UUID) of the docfile
     *                              verification to fetch (required)
     * @return Returned when the docfile verification ID provided is found (status
     *         code 200)
     *         or Returned when an error occur (status code 500)
     */
    @Operation(operationId = "consultDocFileVerificationDetails", summary = "Consult DocFileVerification Details", description = "Consult the details of a DocFileVerification identified by it ID.", tags = {
            "ConsultDocFileVerificationDetails" }, responses = {
                    @ApiResponse(responseCode = "200", description = "Returned when the docfile verification ID provided is found", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ConsultDocFileVerificationDetailsResponseDTO.class))
                    }),
                    @ApiResponse(responseCode = "default", description = "Returned when an error occur", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseErrorDTO.class))
                    })
            })
    @RequestMapping(
        method = RequestMethod.GET, 
        value = "/iam/identities/validations/docfile/verifications/{id}", 
        produces = {"application/json" }
    )

    ResponseEntity<ConsultDocFileVerificationDetailsResponseDTO> _consultDocFileVerificationDetails(
            @Parameter(name = "id", description = "Unique identifier (UUID) of the docfile verification to fetch", required = true, in = ParameterIn.PATH) @PathVariable("id") UUID id);

}
