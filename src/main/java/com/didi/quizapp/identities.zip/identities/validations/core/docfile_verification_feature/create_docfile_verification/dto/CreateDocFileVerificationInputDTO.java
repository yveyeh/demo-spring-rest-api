package com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.format.annotation.DateTimeFormat;

import com.didi.quizapp.helpers.Equals;
import com.didi.quizapp.helpers.HashCode;
import com.didi.quizapp.helpers.ToString;
import com.didi.quizapp.identities.validations.shared.enums.DocFileStatus;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.Valid;

public class CreateDocFileVerificationInputDTO {

    private boolean callMade = false;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime verifiedAt;

    @Enumerated(EnumType.STRING)
    private DocFileStatus verificationStatus;

    private UUID verifiedBy;

    private UUID docFileId;

    private UUID rejectReasonId;

    /**
     * Set the callMade field.
     *
     * @param callMade The callMade flag to set
     * @return The modified CreateDocFileVerificationInputDTO instance
     */
    public CreateDocFileVerificationInputDTO callMade(boolean callMade) {
        this.callMade = callMade;
        return this;
    }

    /**
     * @return boolean return the callMade
     */
    @Valid
    @Schema(name = "call_made", description = "Boolean flag indicating whether call has been made or not", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("call_made")
    public boolean getCallMade() {
        return callMade;
    }

    /**
     * @param callMade the callMade to set
     */
    @JsonProperty("call_made")
    public void setCallMade(boolean callMade) {
        this.callMade = callMade;
    }

    /**
     * Set the verifiedAt field.
     *
     * @param verifiedAt The verifiedAt to set
     * @return The modified CreateDocFileVerificationInputDTO instance
     */
    public CreateDocFileVerificationInputDTO verifiedAt(OffsetDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
        return this;
    }

    /**
     * @return OffsetDateTime return the verifiedAt
     */
    @Valid
    @Schema(name = "verified_at", description = "The date when the document was verified", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("verified_at")
    public OffsetDateTime getVerifiedAt() {
        return verifiedAt;
    }

    /**
     * @param verifiedAt the verifiedAt to set
     */
    @JsonProperty("verified_at")
    public void setVerifiedAt(OffsetDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }

    /**
     * Set the verificationStatus field.
     *
     * @param verificationStatus The verificationStatus to set
     * @return The modified CreateDocFileVerificationInputDTO instance
     */
    public CreateDocFileVerificationInputDTO verificationStatus(DocFileStatus verificationStatus) {
        this.verificationStatus = verificationStatus;
        return this;
    }

    /**
     * @return DocFileStatus return the verificationStatus
     */
    @Valid
    @Schema(name = "verification_status", description = "The status of document verification", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("verification_status")
    public DocFileStatus getVerificationStatus() {
        return verificationStatus;
    }

    /**
     * @param verificationStatus the verificationStatus to set
     */
    @JsonProperty("verification_status")
    public void setVerificationStatus(DocFileStatus verificationStatus) {
        this.verificationStatus = verificationStatus;
    }

    /**
     * Set the verifiedBy field.
     *
     * @param verifiedBy The verifiedBy to set
     * @return The modified CreateDocFileVerificationInputDTO instance
     */
    public CreateDocFileVerificationInputDTO verifiedBy(UUID verifiedBy) {
        this.verifiedBy = verifiedBy;
        return this;
    }

    /**
     * @return UUID return the verifiedBy
     */
    @Valid
    @Schema(name = "verified_by", description = "The ID of the user who callMade the document", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("verified_by")
    public UUID getVerifiedBy() {
        return verifiedBy;
    }

    /**
     * @param verifiedBy the verifiedBy to set
     */
    @JsonProperty("verified_by")
    public void setVerifiedBy(UUID verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    /**
     * Set the docFileId field.
     *
     * @param docFileId The docFileId to set
     * @return The modified CreateDocFileVerificationInputDTO instance
     */
    public CreateDocFileVerificationInputDTO docFileId(UUID docFileId) {
        this.docFileId = docFileId;
        return this;
    }

    /**
     * @return UUID return the docFileId
     */
    @Valid
    @Schema(name = "doc_file_id", description = "The ID of the document file", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("doc_file_id")
    public UUID getDocFileId() {
        return docFileId;
    }

    /**
     * @param docFileId the docFileId to set
     */
    @JsonProperty("doc_file_id")
    public void setDocFileId(UUID docFileId) {
        this.docFileId = docFileId;
    }

    public CreateDocFileVerificationInputDTO rejectReasonId(UUID rejectReasonId) {
        this.rejectReasonId = rejectReasonId;
        return this;
    }

    /**
     * @return UUID return the rejectReasonId
     */
    @Valid
    @Schema(name = "reject_reason_id", description = "The id of the reject reason if any", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("reject_reason_id")
    public UUID getRejectReasonId() {
        return rejectReasonId;
    }

    /**
     * @param rejectReasonId the rejectReasonId to set
     */
    public void setRejectReasonId(UUID rejectReasonId) {
        this.rejectReasonId = rejectReasonId;
    }

    @Override
    public boolean equals(Object object) {
        return Equals.equals(this, object);
    }

    @Override
    public int hashCode() {
        return HashCode.hashCode(this);
    }

    @Override
    public String toString() {
        return ToString.toString(this);
    }

}
