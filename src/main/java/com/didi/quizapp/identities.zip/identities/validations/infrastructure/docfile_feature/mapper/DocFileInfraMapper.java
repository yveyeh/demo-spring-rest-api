package com.didi.quizapp.identities.validations.infrastructure.docfile_feature.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.didi.quizapp.identities.validations.core.docfile_feature.shared.model.DocFileModel;
import com.didi.quizapp.identities.validations.infrastructure.docfile_feature.entity.DocFileEntity;

@Mapper
public interface DocFileInfraMapper {

    DocFileInfraMapper INSTANCE = Mappers.getMapper(DocFileInfraMapper.class);

    DocFileModel map(DocFileEntity docFileEntity);

    DocFileEntity map(DocFileModel docFileModel);

    List<DocFileModel> map(List<DocFileEntity> docFileEntities);

}
