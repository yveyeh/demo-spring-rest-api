package com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.usecase;

import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.create_docfile_verification.dto.CreateDocFileVerificationOutputDTO;

import java.util.UUID;

public interface CreateDocFileVerificationUseCase {

    CreateDocFileVerificationOutputDTO createDocFileVerification(
        UUID docFileId, CreateDocFileVerificationInputDTO docFileVerificationInputDTO);

}
