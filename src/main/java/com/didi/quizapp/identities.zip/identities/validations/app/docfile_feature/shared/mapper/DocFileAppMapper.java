package com.didi.quizapp.identities.validations.app.docfile_feature.shared.mapper;

import com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_details.dto.ConsultDocFileDetailsResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_list.dto.ConsultDocFileListResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.create_docfile.dto.CreateDocFileRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.create_docfile.dto.CreateDocFileResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.update_docfile.dto.UpdateDocFileRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.update_docfile.dto.UpdateDocFileResponseDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_details.dto.ConsultDocFileDetailsOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_list.dto.ConsultDocFileListOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.dto.CreateDocFileInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.create_docfile.dto.CreateDocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.dto.UpdateDocFileInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.dto.UpdateDocFileOutputDTO;

import org.mapstruct.Mapper;
// import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface DocFileAppMapper {

    DocFileAppMapper INSTANCE = Mappers.getMapper(DocFileAppMapper.class);

    ConsultDocFileDetailsResponseDTO map(ConsultDocFileDetailsOutputDTO consultDocFileDetailsOutputDTO);

    ConsultDocFileListResponseDTO map(ConsultDocFileListOutputDTO consultDocFileListOutputDTO);

    CreateDocFileInputDTO map(CreateDocFileRequestDTO CreateDocFileRequestDTO);

    CreateDocFileResponseDTO map(CreateDocFileOutputDTO createDocFileOutputDTO);

    UpdateDocFileResponseDTO map(UpdateDocFileOutputDTO updateDocFileOutputDTO);

    UpdateDocFileInputDTO map(UpdateDocFileRequestDTO updateDocFileRequestDTO);
    
}
