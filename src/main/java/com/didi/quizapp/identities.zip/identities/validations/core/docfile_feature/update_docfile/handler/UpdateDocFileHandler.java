package com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.handler;

import java.math.BigDecimal;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.didi.quizapp.identities.validations.core.docfile_feature.shared.dto.DocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.mapper.DocFileCoreMapper;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.model.DocFileModel;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.repository.DocFileRepositoryPort;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.dto.UpdateDocFileInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.dto.UpdateDocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.update_docfile.usecase.UpdateDocFileUseCase;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class UpdateDocFileHandler implements UpdateDocFileUseCase {

    @Autowired
    private DocFileRepositoryPort docFileRepositoryPort;

    @Override
    public UpdateDocFileOutputDTO update(UUID docFileId, UpdateDocFileInputDTO docFileInputDTO) {
        long startTime = System.currentTimeMillis();


        DocFileModel docFileModel = docFileRepositoryPort.findById(docFileId)
                .orElseThrow(() -> new IllegalArgumentException("DocFile not found"));

        DocFileCoreMapper.INSTANCE.updateDocFileModelFromUpdateDocFileInputDTO(docFileInputDTO, docFileModel);

        docFileRepositoryPort.saveAndFlush(docFileModel);

        UpdateDocFileOutputDTO updateDocFileOutputDTO = new UpdateDocFileOutputDTO();

        DocFileOutputDTO docFileOutputDTO = DocFileCoreMapper.INSTANCE.map(docFileModel);

        updateDocFileOutputDTO.setData(docFileOutputDTO);

        long endTime = System.currentTimeMillis();

        updateDocFileOutputDTO.setElapsedTime(BigDecimal.valueOf(endTime - startTime));

        return updateDocFileOutputDTO;

    }

}
