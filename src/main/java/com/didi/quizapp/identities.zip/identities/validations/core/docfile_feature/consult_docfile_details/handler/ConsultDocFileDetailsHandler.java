package com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_details.handler;

import java.math.BigDecimal;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_details.dto.ConsultDocFileDetailsOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_details.usecase.ConsultDocFileDetailsUseCase;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.dto.DocFileOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.mapper.DocFileCoreMapper;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.model.DocFileModel;
import com.didi.quizapp.identities.validations.core.docfile_feature.shared.repository.DocFileRepositoryPort;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class ConsultDocFileDetailsHandler implements ConsultDocFileDetailsUseCase {

    @Autowired
    private DocFileRepositoryPort docFileRepositoryPort;

    @Override
    public ConsultDocFileDetailsOutputDTO consultDocFileDetails(UUID docFileId) {

        long startTime = System.currentTimeMillis();

        DocFileModel docFileModel = docFileRepositoryPort.findById(docFileId).orElseThrow(() -> new IllegalArgumentException("File not found"));

        ConsultDocFileDetailsOutputDTO consultDocFileDetailsOutputDTO = new ConsultDocFileDetailsOutputDTO();

        DocFileOutputDTO docFileOutputDTO = DocFileCoreMapper.INSTANCE.map(docFileModel);

        consultDocFileDetailsOutputDTO.setData(docFileOutputDTO);

        long endTime = System.currentTimeMillis();

        consultDocFileDetailsOutputDTO.setElapsedTime(BigDecimal.valueOf(endTime - startTime));

        return consultDocFileDetailsOutputDTO;
    }

}
