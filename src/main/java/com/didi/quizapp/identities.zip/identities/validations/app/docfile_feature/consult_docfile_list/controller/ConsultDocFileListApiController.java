package com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_list.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_list.api.ConsultDocFileListApi;
import com.didi.quizapp.identities.validations.app.docfile_feature.consult_docfile_list.dto.ConsultDocFileListResponseDTO;
import com.didi.quizapp.identities.validations.app.docfile_feature.shared.mapper.DocFileAppMapper;
import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_list.dto.ConsultDocFileListOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_list.handler.ConsultDocFileListHandler;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
public class ConsultDocFileListApiController implements ConsultDocFileListApi {

    @Autowired
    private ConsultDocFileListHandler consultDocFileListHandler;

    // public ConsultDocFileListApiController(ConsultDocFileListHandler consultDocFileListHandler) {
    //     this.consultDocFileListHandler = consultDocFileListHandler;
    // }

    @Override
    public ResponseEntity<ConsultDocFileListResponseDTO> _consultDocFileList(Integer page, Integer size) {
        try {
            ConsultDocFileListOutputDTO outputDTO = consultDocFileListHandler.consultDocFileList(page, size);
            ConsultDocFileListResponseDTO responseDTO = DocFileAppMapper.INSTANCE.map(outputDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}