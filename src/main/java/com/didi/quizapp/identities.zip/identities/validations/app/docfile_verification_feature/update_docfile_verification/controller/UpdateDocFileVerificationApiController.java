package com.didi.quizapp.identities.validations.app.docfile_verification_feature.update_docfile_verification.controller;

import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.didi.quizapp.identities.validations.app.docfile_verification_feature.shared.mapper.DocFileVerificationAppMapper;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.update_docfile_verification.api.UpdateDocFileVerificationApi;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationRequestDTO;
import com.didi.quizapp.identities.validations.app.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationResponseDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationInputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.dto.UpdateDocFileVerificationOutputDTO;
import com.didi.quizapp.identities.validations.core.docfile_verification_feature.update_docfile_verification.handler.UpdateDocFileVerificationHandler;

// import io.swagger.v3.oas.annotations.parameters.RequestBody;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class UpdateDocFileVerificationApiController implements UpdateDocFileVerificationApi {

    @Autowired
    private UpdateDocFileVerificationHandler updateDocFileVerificationHandler;

    @Override
    // @PutMapping("/iam/identities/validations/docfile/verifications/{id}")
    public ResponseEntity<UpdateDocFileVerificationResponseDTO> _updateDocFileVerificationDetails(
            UUID id, 
            UpdateDocFileVerificationRequestDTO updateDocFileVerificationRequestDTO) 
    {
        try {
            UpdateDocFileVerificationInputDTO inputDTO = DocFileVerificationAppMapper.INSTANCE
                    .map(updateDocFileVerificationRequestDTO);
            UpdateDocFileVerificationOutputDTO outputDTO = updateDocFileVerificationHandler
                    .update(id, inputDTO);
            UpdateDocFileVerificationResponseDTO responseDTO = DocFileVerificationAppMapper.INSTANCE.map(outputDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        } catch (IllegalArgumentException exception) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
