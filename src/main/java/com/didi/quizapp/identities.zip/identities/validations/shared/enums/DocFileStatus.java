package com.didi.quizapp.identities.validations.shared.enums;

public enum DocFileStatus {
    MISSING,
    PENDING,
    APPROVED,
    REJECTED
}
