package com.didi.quizapp.identities.validations.app.docfile_feature.shared.dto;

import com.didi.quizapp.helpers.*;
import com.didi.quizapp.identities.validations.shared.enums.DocFileStatus;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.Valid;
// import jakarta.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DocFileResponseDTO
 */

public class DocFileResponseDTO {

  private UUID id;

  private String description;

  private boolean verified = false;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private OffsetDateTime verifiedAt;

  @Enumerated(EnumType.STRING)
  private DocFileStatus verificationStatus;

  private UUID verifiedBy;

  private UUID docFileTypeId;

  private UUID idDocId;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private OffsetDateTime createdAt;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private OffsetDateTime updatedAt;

  public DocFileResponseDTO id(UUID id) {
    this.id = id;
    return this;
  }

  /**
   * ID of the docfile
   * 
   * @return id
   */
  @Valid
  @Schema(name = "id", accessMode = Schema.AccessMode.READ_ONLY, description = "ID of the docfile", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public UUID getId() {
    return id;
  }

  @JsonProperty("id")
  public void setId(UUID id) {
    this.id = id;
  }

  /**
   * Set the description field.
   *
   * @param description The description to set
   * @return The modified DocFileResponseDTO instance
   */
  public DocFileResponseDTO description(String description) {
    this.description = description;
    return this;
  }

  /**
   * @return String return the description
   */
  @Valid
  @Schema(name = "description", description = "The description of the document", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }

  /**
   * @param description the description to set
   */
  @JsonProperty("description")
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Set the verified field.
   *
   * @param verified The verified flag to set
   * @return The modified DocFileResponseDTO instance
   */
  public DocFileResponseDTO verified(boolean verified) {
    this.verified = verified;
    return this;
  }

  /**
   * @return boolean return the verified
   */
  @Valid
  @Schema(name = "verified", description = "Boolean flag indicating whether the document is verified or not", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("verified")
  public boolean isVerified() {
    return verified;
  }

  /**
   * @param verified the verified to set
   */
  @JsonProperty("verified")
  public void setVerified(boolean verified) {
    this.verified = verified;
  }

  /**
   * Set the verifiedAt field.
   *
   * @param verifiedAt The verifiedAt to set
   * @return The modified DocFileResponseDTO instance
   */
  public DocFileResponseDTO verifiedAt(OffsetDateTime verifiedAt) {
    this.verifiedAt = verifiedAt;
    return this;
  }

  /**
   * @return OffsetDateTime return the verifiedAt
   */
  @Valid
  @Schema(name = "verified_at", description = "The date when the document was verified", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("verified_at")
  public OffsetDateTime getVerifiedAt() {
    return verifiedAt;
  }

  /**
   * @param verifiedAt the verifiedAt to set
   */
  @JsonProperty("verified_at")
  public void setVerifiedAt(OffsetDateTime verifiedAt) {
    this.verifiedAt = verifiedAt;
  }

  /**
   * Set the verificationStatus field.
   *
   * @param verificationStatus The verificationStatus to set
   * @return The modified DocFileResponseDTO instance
   */
  public DocFileResponseDTO verificationStatus(DocFileStatus verificationStatus) {
    this.verificationStatus = verificationStatus;
    return this;
  }

  /**
   * @return DocFileStatus return the verificationStatus
   */
  @Valid
  @Schema(name = "verification_status", description = "The status of document verification", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("verification_status")
  public DocFileStatus getVerificationStatus() {
    return verificationStatus;
  }

  /**
   * @param verificationStatus the verificationStatus to set
   */
  @JsonProperty("verification_status")
  public void setVerificationStatus(DocFileStatus verificationStatus) {
    this.verificationStatus = verificationStatus;
  }

  /**
   * Set the verifiedBy field.
   *
   * @param verifiedBy The verifiedBy to set
   * @return The modified DocFileResponseDTO instance
   */
  public DocFileResponseDTO verifiedBy(UUID verifiedBy) {
    this.verifiedBy = verifiedBy;
    return this;
  }

  /**
   * @return UUID return the verifiedBy
   */
  @Valid
  @Schema(name = "verified_by", description = "The ID of the user who verified the document", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("verified_by")
  public UUID getVerifiedBy() {
    return verifiedBy;
  }

  /**
   * @param verifiedBy the verifiedBy to set
   */
  @JsonProperty("verified_by")
  public void setVerifiedBy(UUID verifiedBy) {
    this.verifiedBy = verifiedBy;
  }

  /**
   * Set the docFileTypeId field.
   *
   * @param docFileTypeId The docFileTypeId to set
   * @return The modified DocFileResponseDTO instance
   */
  public DocFileResponseDTO docFileTypeId(UUID docFileTypeId) {
    this.docFileTypeId = docFileTypeId;
    return this;
  }

  /**
   * @return UUID return the docFileTypeId
   */
  @Valid
  @Schema(name = "doc_file_type_id", description = "The ID of the document file type", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("doc_file_type_id")
  public UUID getDocFileTypeId() {
    return docFileTypeId;
  }

  /**
   * @param docFileTypeId the docFileTypeId to set
   */
  @JsonProperty("doc_file_type_id")
  public void setDocFileTypeId(UUID docFileTypeId) {
    this.docFileTypeId = docFileTypeId;
  }

  public DocFileResponseDTO idDocId(UUID idDocId) {
    this.idDocId = idDocId;
    return this;
  }

  /**
   * @return UUID return the idDocId
   */
  @Valid
  @Schema(name = "id_doc_id", description = "The id of the doc ID", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id_doc_id")
  public UUID getIdDocId() {
    return idDocId;
  }

  /**
   * @param idDocId the idDocId to set
   */
  @JsonProperty("id_doc_id")
  public void setIdDocId(UUID idDocId) {
    this.idDocId = idDocId;
  }

  public DocFileResponseDTO createdAt(OffsetDateTime createdAt) {
    this.createdAt = createdAt;
    return this;
  }

  /**
   * The creation date of the docfile
   * 
   * @return createdAt
   */
  @Valid
  @Schema(name = "created_at", description = "The creation date of the docfile", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("created_at")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

  @JsonProperty("created_at")
  public void setCreatedAt(OffsetDateTime createdAt) {
    this.createdAt = createdAt;
  }

  public DocFileResponseDTO updatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

  /**
   * The last modified date of the docfile
   * 
   * @return updatedAt
   */
  @Valid
  @Schema(name = "updated_at", description = "The last modified date of the docfile", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("updated_at")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  @JsonProperty("updated_at")
  public void setUpdatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
  }

  @Override
  public boolean equals(Object object) {
    return Equals.equals(this, object);
  }

  @Override
  public int hashCode() {
    return HashCode.hashCode(this);
  }

  @Override
  public String toString() {
    return ToString.toString(this);
  }

}
