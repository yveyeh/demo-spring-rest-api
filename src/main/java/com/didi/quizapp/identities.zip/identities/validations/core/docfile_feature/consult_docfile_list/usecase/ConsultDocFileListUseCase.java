package com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_list.usecase;

import com.didi.quizapp.identities.validations.core.docfile_feature.consult_docfile_list.dto.ConsultDocFileListOutputDTO;

public interface ConsultDocFileListUseCase {
    ConsultDocFileListOutputDTO consultDocFileList(Integer page, Integer size);
}
