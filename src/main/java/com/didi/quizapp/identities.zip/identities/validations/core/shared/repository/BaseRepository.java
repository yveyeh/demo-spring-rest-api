package com.didi.quizapp.identities.validations.core.shared.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface BaseRepository<T> {
    T saveAndFlush(T model);

    T getById(UUID uuid);

    T save(T model);

    Optional<T> findById(UUID uuid);

    boolean existsById(UUID uuid);

    List<T> findAll();

    long count();

    void delete(T model);

    void deleteById(UUID uuid);

    Page<T> findAll(Pageable pageable);

    // @Query(value = "SELECT * FROM doc_file_verifications d WHERE d.doc_file_id=:docFileId ORDER BY d.created_at DESC", nativeQuery = true)
    Page<T> findByDocFileId(Pageable pageable, UUID docFileId);
}
